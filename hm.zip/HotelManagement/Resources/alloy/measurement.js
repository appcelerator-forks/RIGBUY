

var dpi = Ti.Platform.displayCaps.dpi,
    density = Ti.Platform.displayCaps.density;

exports.dpToPX = function (val) {
	if (false) {
		return val * dpi / 160;
	} else if (true) {
		switch (density) {
			case 'xhigh':
				return val * 3;
			case 'high':
				return val * 2;
			default:
				return val;
		}
	} else {
		return val;
	}
};

exports.pxToDP = function (val) {
	if (false) {
		return val / dpi * 160;
	} else if (true) {
		switch (density) {
			case 'xhigh':
				return val / 3;
			case 'high':
				return val / 2;
			default:
				return val;
		}
	} else {
		return val;
	}
};

exports.pointPXToDP = function (pt) {
	if (false || true) {
		return { x: exports.pxToDP(pt.x), y: exports.pxToDP(pt.y) };
	} else {
		return pt;
	}
};