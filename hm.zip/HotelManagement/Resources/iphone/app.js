




var Alloy = require('/alloy'),
_ = Alloy._,
Backbone = Alloy.Backbone;
























Alloy.Globals.Communicator = require('Communicator');
Alloy.Globals.Constants = require('Constants');
Alloy.Globals.Measurement = require('alloy/measurement');

if (true) {
	Alloy.Globals.LoadingScreen = Alloy.createWidget('Loader').getView();

} else {
	Alloy.Globals.LoadingScreen = Alloy.createWidget('Loader');

}

Alloy.Globals.iPhoneTall = true && Ti.Platform.osname == "iphone" && Ti.Platform.displayCaps.platformHeight == 480;
Alloy.Globals.iPhone5s = true && Ti.Platform.osname == "iphone" && Ti.Platform.displayCaps.platformHeight == 568;
Alloy.Globals.iPhoneIpad = Ti.Platform.osname == "ipad";

Alloy.Globals.iPhoneSixPlus = true && Ti.Platform.osname == "iphone" && Ti.Platform.displayCaps.platformHeight == 736;

Alloy.Globals.iPhoneSix = true && Ti.Platform.osname == "iphone" && Ti.Platform.displayCaps.platformHeight == 667;

Alloy.Globals.iPhoneTallSixPlus = true && Ti.Platform.osname == "iphone" && Ti.Platform.displayCaps.platformHeight == 736 || Ti.Platform.displayCaps.platformHeight == 667;
String.prototype.capitalize = function () {
	try {
		return this.charAt(0).toUpperCase() + this.slice(1);
	} catch (e) {
		Ti.API.info('Error Fun : capitalize ');
	}
};
Alloy.Globals.langConvert = function L(text) {

	try {
		var lang = Titanium.App.Properties.getString('locale');
		if (lang) {
			file = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, "strings" + lang.toUpperCase() + ".xml");
		} else {
			file = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, "stringsEN.xml");
		}



		if (!file.exists()) {
			var langFile = "en";
		}
		var xmltext = file.read().text;
		var xmldata = Titanium.XML.parseString(xmltext);

		Ti.App.languageXML = xmldata;


		var xpath = "/resources/string[@name='" + text + "']/text()";
		var result = Ti.App.languageXML.evaluate(xpath).item(0);
		if (result) {
			return result.text;
		} else {
			return text;
		}
	} catch (e) {
		Ti.API.info("Error langConvert " + e.message);
	}

};

Alloy.Globals.Alert = function (message) {
	var dialog = Ti.UI.createAlertDialog({
		title: Alloy.Globals.langConvert("app_name") });

	dialog.ok = Alloy.Globals.langConvert("ok");
	dialog.message = message;
	dialog.show();

};

Alloy.Globals.padding = Ti.Platform.displayCaps.platformWidth * 0.0580;
Alloy.Globals.padding1 = Alloy.Globals.padding * 2 + Alloy.Globals.padding;
Alloy.Globals.androidVersion = Ti.Platform.version.split('.');
Ti.API.info('Alloy.Globals.androidVersion ' + Alloy.Globals.padding + " Alloy.Globals.padding1 " + Alloy.Globals.padding1);

Alloy.Globals.padding_search_img = Alloy.Globals.padding + 10;

Alloy.Globals.normalpadding = Ti.Platform.displayCaps.platformWidth * 0.036;
Ti.API.info(" Alloy.Globals.normalpadding " + Alloy.Globals.normalpadding);


defaultWidth = 320;


deviceWidth = Titanium.Platform.displayCaps.platformWidth;
Alloy.Globals.scaleFactor = deviceWidth / defaultWidth;


Alloy.Globals.loadingLbl.text = "Please wait...";






Alloy.Globals.Notifier = Alloy.createWidget('ti.notifications', {
	message: 'Notification Test',
	duration: 2000,

	style: 'notification',
	elasticity: 0.5,
	pushForce: 30,
	usePhysicsEngine: true,
	animationDuration: 200 });


Alloy.createController('index');