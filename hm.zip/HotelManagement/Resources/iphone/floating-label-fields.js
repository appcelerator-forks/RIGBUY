var defaults = {
    bottom: 0,
    color: "#000000",
    delay: 100,
    duration: 200,
    height: "7.40%",
    hintText: "Textfield",
    hintTextColor: "#e9dddd",
    hintTextFocusColor: "#dc1474",
    hintTextFont: {
        fontSize: 13 * Alloy.Globals.scaleFactor,
        fontWeight: 'bold'
    },
    font: {
        fontFamily: "HelveticaNeue-Regular",
        fontSize: 16 * Alloy.Globals.scaleFactor
    },
    left: null,
    right: null,
    top: null,
    width: Ti.UI.FILL,
    feild: "normal"
};

function pickOutExtraOptions(options) {
    var extraOptions = {};

    for (var option in options) {
        if (defaults[option] === undefined) {
            extraOptions[option] = options[option];
        }
    }

    return extraOptions;
}

exports.createTextField = function () {
    var options = arguments[0] || {};

    var fadeIn = Ti.UI.createAnimation({
        delay: defaults.delay || options.delay,
        duration: defaults.duration || options.duration,
        opacity: 1.0
    });
    var fadeOut = Ti.UI.createAnimation({
        duration: defaults.duration || options.duration,
        opacity: 0.0
    });

    var transitionToFocusColor = Ti.UI.createAnimation({
        color: options.hintTextFocusColor || defaults.hintTextFocusColor,
        duration: defaults.duration
    });
    var transitionToBlurColor = Ti.UI.createAnimation({
        color: options.hintTextColor || defaults.hintTextColor,
        duration: defaults.duration
    });

    if (options.hintText === undefined && typeof options.hintText === "string") {
        throw {
            name: "Missing Required Argument",
            message: "FloatingLabelFields module requires a `hintText` keyword argument of type string."
        };
    }

    var container = Ti.UI.createView({

        borderColor: options.borderColor || defaults.borderColor,
        borderWidth: options.borderWidth || defaults.borderWidth,
        height: options.height || defaults.height,

        width: options.width || defaults.width
    });

    if (options.left) {
        container.left = options.left;
    }

    if (options.right) {
        container.right = options.right;
    }

    if (options.top) {
        container.top = options.top;
    }

    if (options.bottom) {
        container.bottom = options.bottom;
    }

    var floatingLabel = Ti.UI.createLabel({
        color: options.hintTextColor || defaults.hintTextColor,
        font: options.hintTextFont || defaults.hintTextFont,
        height: options.hintTextFont && options.hintTextFont.fontSize ? options.hintTextFont.fontSize + 3 : defaults.hintTextFont.fontSize + 3,
        left: 0,
        minimumFontSize: options.hintTextFont && options.hintTextFont.fontSize ? options.hintTextFont.fontSize : defaults.hintTextFont.fontSize,
        opacity: 0,
        text: options.hintText,
        textAlign: 'left',
        top: 0
    });
    var textField = Ti.UI.createTextField({
        borderWidth: 0,
        font: options.font || defaults.font,
        height: options.font && options.font.fontSize ? options.font.fontSize + 3 : defaults.font.fontSize + 3,
        hintText: options.hintText,
        left: 0,
        bottom: 0,
        right: "12%"

    });
    var padding = Ti.UI.createView({
        height: 5,
        width: Ti.UI.SIZE
    });

    textField.applyProperties(pickOutExtraOptions(options));

    container.add(floatingLabel);
    container.add(textField);
    container.add(padding);

    container.addEventListener('click', function () {
        textField.focus();
    });

    textField.addEventListener('change', function (e) {
        if (e.value.length === 0) {
            floatingLabel.animate(fadeOut);
        } else {
            floatingLabel.animate(fadeIn);
        }
    });

    textField.addEventListener('focus', function () {
        floatingLabel.animate(transitionToFocusColor);
    });

    textField.addEventListener('blur', function () {
        floatingLabel.animate(transitionToBlurColor);
    });

    container.textField = textField;

    return container;
};

exports.createTextArea = function () {
    var options = arguments[0] || {};
};