var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;


function WPATH(s) {
		var index = s.lastIndexOf('/');
		var path = index === -1 ?
		'nl.fokkezb.html2as/' + s :
		s.substring(0, index) + '/nl.fokkezb.html2as/' + s.substring(index + 1);

		return path.indexOf('/') !== 0 ? '/' + path : path;
}

function __processArg(obj, key) {
		var arg = null;
		if (obj) {
				arg = obj[key] || null;
				delete obj[key];
		}
		return arg;
}

function Controller() {
		var Widget = new (require('/alloy/widget'))('nl.fokkezb.html2as');this.__widgetId = 'nl.fokkezb.html2as';
		require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
		this.__controllerPath = 'widget';
		this.args = arguments[0] || {};

		if (arguments[0]) {
				var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
				var $model = __processArg(arguments[0], '$model');
				var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
		}
		var $ = this;
		var exports = {};
		var __defers = {};







		$.__views.label = Ti.UI.createLabel(
		function () {
				var o = {};
				Alloy.deepExtend(true, o, { color: "#000", font: { fontSize: 18, fontWeight: "bold" }, height: Ti.UI.SIZE, width: Ti.UI.SIZE });
				if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
				if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
				Alloy.deepExtend(true, o, { id: "label" });
				return o;
		}());

		$.__views.label && $.addTopLevelView($.__views.label);
		exports.destroy = function () {};




		_.extend($, $.__views);


		var html2as = require('nl.fokkezb.html2as');

		$.applyProperties = function applyProperties(props) {

				if (props.html) {
						$.html = props.html;
				}

				$.label.applyProperties(props);
		};

		$.on = $.addEventListener = function (name, callback) {
				return $.label.addEventListener(name, callback);
		};

		$.off = $.removeEventListener = function (name, callback) {
				return $.label.removeEventListener(name, callback);
		};

		$.trigger = $.fireEvent = function (name, e) {
				return $.label.fireEvent(name, e);
		};

		$.setHtml = function setHtml(html) {

				$.label.html = html;

				if (true) {
						html2as(html, function handle(err, as) {

								if (err) {
										console.error('[nl.fokkezb.html2as.widget] ' + err);
								} else {
										$.label.attributedString = as;
								}
						});
				}
		};

		$.getHtml = function getHtml() {
				return $.label.html;
		};

		Object.defineProperty($, 'html', {
				get: $.getHtml,
				set: $.setHtml });


		$.applyProperties(arguments[0] || {});









		_.extend($, exports);
}

module.exports = Controller;