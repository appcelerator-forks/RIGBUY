var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;


function WPATH(s) {
  var index = s.lastIndexOf('/');
  var path = index === -1 ?
  'ti.notifications/' + s :
  s.substring(0, index) + '/ti.notifications/' + s.substring(index + 1);

  return path.indexOf('/') !== 0 ? '/' + path : path;
}

function __processArg(obj, key) {
  var arg = null;
  if (obj) {
    arg = obj[key] || null;
    delete obj[key];
  }
  return arg;
}

function Controller() {
  var Widget = new (require('/alloy/widget'))('ti.notifications');this.__widgetId = 'ti.notifications';
  require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
  this.__controllerPath = 'window';
  this.args = arguments[0] || {};

  if (arguments[0]) {
    var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
    var $model = __processArg(arguments[0], '$model');
    var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
  }
  var $ = this;
  var exports = {};
  var __defers = {};







  $.__views.caffeinaToastView = Ti.UI.createView(
  { top: 0, backgroundColor: "#A000", height: 65, touchEnabled: false, layout: "composite", apiName: "Ti.UI.View", classes: ["caffeinaToastView"], id: "caffeinaToastView" });

  $.__views.caffeinaToastView && $.addTopLevelView($.__views.caffeinaToastView);
  $.__views.caffeinaToastIcon = Ti.UI.createImageView(
  { left: 8, height: 42, borderRadius: 10, apiName: "Ti.UI.ImageView", classes: ["caffeinaToastIcon"], id: "caffeinaToastIcon" });

  $.__views.caffeinaToastView.add($.__views.caffeinaToastIcon);
  $.__views.caffeinaToastLabel = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { touchEnabled: false, left: 10, top: 20, right: 10, bottom: 0, color: "#fff", textAlign: "center", font: { fontSize: 12, fontFamily: "Roboto-Regular" }, apiName: "Ti.UI.Label", classes: ["caffeinaToastLabel"], id: "caffeinaToastLabel" });
    return o;
  }());

  $.__views.caffeinaToastView.add($.__views.caffeinaToastLabel);
  exports.destroy = function () {};




  _.extend($, $.__views);


  var args = arguments[0] || {};
  var timeout = null;
  var $container = null;

  function ucfirst(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }





  exports.hide = function () {
    clearTimeout(timeout);

    $container.animate({
      transform: Ti.UI.create2DMatrix().translate(0, -$container.height),
      duration: 200 },
    function () {
      if (args.view != null) {
        args.view.remove($container);
      } else {
        $container.close();
      }

      if (_.isFunction(args.onClose)) args.onClose();
    });
  };

  exports.setMessage = function (message) {
    $.caffeinaToastLabel.text = message;
  };

  exports.setIcon = function (icon) {
    if (icon == null) {
      $.resetClass($.caffeinaToastLabel, "caffeinaToastLabel caffeinaToastLabelWithoutIcon");
    } else {
      $.resetClass($.caffeinaToastLabel, "caffeinaToastLabel");
      $.caffeinaToastIcon.image = icon;
    }
  };

  exports.setStyle = function (style) {
    $.resetClass($.caffeinaToastView, "caffeinaToastView caffeinaToast" + ucfirst(style || "default"));
  };





  if (args.message != null) exports.setMessage(args.message);
  if (args.style != null) exports.setStyle(args.style);

  exports.setIcon(args.icon);

  if (args.view == null) {
    $container = Ti.UI.createWindow({
      backgroundColor: 'transparent',

      statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_DARK });

  } else {
    $container = Ti.UI.createView({
      backgroundColor: 'transparent' });

    args.view.add($container);
  }

  $container.addEventListener('touchstart', function (e) {
    exports.hide();
    if (_.isFunction(args.onClick)) args.onClick(e);
  });

  if (true && args.usePhysicsEngine === true && Ti.UI.iOS.createAnimator != null) {

    var animator = Ti.UI.iOS.createAnimator({ referenceView: $container });
    var collision = Ti.UI.iOS.createCollisionBehavior();
    var dy = Ti.UI.iOS.createDynamicItemBehavior({ elasticity: args.elasticity });
    var pusher = Ti.UI.iOS.createPushBehavior({ pushDirection: { x: 0, y: args.pushForce } });

    collision.addItem($.caffeinaToastView);
    dy.addItem($.caffeinaToastView);
    pusher.addItem($.caffeinaToastView);

    animator.addBehavior(collision);
    animator.addBehavior(dy);
    animator.addBehavior(pusher);

    $container.applyProperties({ height: 150, top: -86 });
    $container.add($.caffeinaToastView);

    if (_.isFunction($container.open)) {
      $container.addEventListener('open', function () {
        animator.startAnimator();
      });
      $container.open();
    } else {
      animator.startAnimator();
    }
  } else {

    $container.applyProperties({ height: 65, top: -65 });
    $container.add($.caffeinaToastView);

    if (_.isFunction($container.open)) {
      $container.addEventListener('open', function () {
        $container.animate({ top: 0, duration: args.animationDuration });
      });
      $container.open();
    } else {
      $container.animate({ top: 0, duration: args.animationDuration });
    }
  }


  if (args.duration != null) {
    timeout = setTimeout(exports.hide, args.duration);
  }









  _.extend($, exports);
}

module.exports = Controller;