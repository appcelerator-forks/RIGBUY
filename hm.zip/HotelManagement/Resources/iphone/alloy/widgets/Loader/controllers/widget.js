var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;


function WPATH(s) {
	var index = s.lastIndexOf('/');
	var path = index === -1 ?
	'Loader/' + s :
	s.substring(0, index) + '/Loader/' + s.substring(index + 1);

	return path.indexOf('/') !== 0 ? '/' + path : path;
}

function __processArg(obj, key) {
	var arg = null;
	if (obj) {
		arg = obj[key] || null;
		delete obj[key];
	}
	return arg;
}

function Controller() {
	var Widget = new (require('/alloy/widget'))('Loader');this.__widgetId = 'Loader';
	require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
	this.__controllerPath = 'widget';
	this.args = arguments[0] || {};

	if (arguments[0]) {
		var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
		var $model = __processArg(arguments[0], '$model');
		var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
	}
	var $ = this;
	var exports = {};
	var __defers = {};







	if (true) {
		$.__views.widget = Ti.UI.createWindow(
		function () {
			var o = {};
			if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
			if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
			Alloy.deepExtend(true, o, { backgroundColor: "transparent", statusBarStyle: Titanium.UI.iOS.StatusBar.LIGHT_CONTENT, id: "widget" });
			return o;
		}());

		$.__views.widget && $.addTopLevelView($.__views.widget);
		$.__views.ActivityView = Ti.UI.createView(
		{ backgroundColor: "black", opacity: 0.8, width: 120, height: 120, borderRadius: 10, id: "ActivityView" });

		$.__views.widget.add($.__views.ActivityView);
		$.__views.activityIndicator = Ti.UI.createActivityIndicator(
		{ top: 32, height: 28, width: 28, id: "activityIndicator" });

		$.__views.ActivityView.add($.__views.activityIndicator);
		$.__views.loadingLabel = Ti.UI.createLabel(
		function () {
			var o = {};
			if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
			if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
			Alloy.deepExtend(true, o, { color: "white", bottom: 12, font: { fontSize: 15, fontFamily: "Roboto-Regular" }, id: "loadingLabel" });
			return o;
		}());

		$.__views.ActivityView.add($.__views.loadingLabel);
	}
	exports.destroy = function () {};




	_.extend($, $.__views);


	if (true) {
		Alloy.Globals.loadingLbl = $.loadingLabel;
	} else {
		Alloy.Globals.loadingLbl = $.activityIndicatorAnd;
	}
	var lang = Ti.App.Properties.getString("locale");
	if (true) {

		Alloy.Globals.loadingLbl.text = "Please wait...";
	}
	if (true) {
		$.activityIndicator.show();
	}

	exports.open = function () {

		$.activityIndicatorAnd.show();
	};

	exports.close = function () {

		$.activityIndicatorAnd.hide();
	};









	_.extend($, exports);
}

module.exports = Controller;