var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
  var arg = null;
  if (obj) {
    arg = obj[key] || null;
    delete obj[key];
  }
  return arg;
}

function Controller() {

  require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
  this.__controllerPath = 'MyCart';
  this.args = arguments[0] || {};

  if (arguments[0]) {
    var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
    var $model = __processArg(arguments[0], '$model');
    var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
  }
  var $ = this;
  var exports = {};
  var __defers = {};







  $.__views.MyCart = Ti.UI.createWindow(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    Alloy.deepExtend(true, o, { title: "My Cart", backButtonTitle: "", backgroundColor: "#E5E6E8", id: "MyCart" });
    return o;
  }());

  $.__views.MyCart && $.addTopLevelView($.__views.MyCart);
  openFunc ? $.addListener($.__views.MyCart, 'open', openFunc) : __defers['$.__views.MyCart!open!openFunc'] = true;$.__views.__alloyId26 = Ti.UI.createView(
  { backgroundColor: "transparent", height: 1, id: "__alloyId26" });

  $.__views.cartTableView = Ti.UI.createTableView(
  { footerView: $.__views.__alloyId26, backgroundColor: "transparent", separatorColor: "transparent", id: "cartTableView" });

  $.__views.MyCart.add($.__views.cartTableView);
  exports.destroy = function () {};




  _.extend($, $.__views);



  var args = $.args;
  var tableData = [];


  var Communicator = Alloy.Globals.Communicator;
  var DOMAIN_URL = Alloy.Globals.Constants.DOMAIN_URL;
  var lang = Titanium.App.Properties.getString('locale');

  if (true) {

    var btnVW = Titanium.UI.createView({
      width: 40,
      height: 40 });



    var toggleBtn = Titanium.UI.createButton({
      backgroundImage: "none" });

    btnVW.add(toggleBtn);

    if (lang == "ar") {
      toggleBtn.right = 0;
      toggleBtn.image = "/images/barrow_ar.png";
    } else {
      toggleBtn.left = 0;
      toggleBtn.image = "/images/back.png";
    }

    $.MyCart.title = Alloy.Globals.langConvert("mycart");
    if (lang == "ar") {
      $.MyCart.rightNavButton = btnVW;
    } else {
      $.MyCart.leftNavButton = btnVW;
    }
    btnVW.addEventListener('click', function (e) {
      $.MyCart.close();
    });
  }

  Alloy.Globals.createNewsRow = function (detail) {
    tableData = [];
    for (var i = 0; i < detail.length; i++) {

      var tableRow = Ti.UI.createTableViewRow({
        touchEnabled: true,

        width: "100%",
        height: "30%",
        detail: detail[i],
        selectedBackgroundColor: "#F8F8F9" });

      if (true) {

      }

      tableRow.add(Ti.UI.createView({
        height: "96%",
        width: "96%",
        backgroundColor: "white" }));



      tableRow.getChildren()[0].add(Ti.UI.createImageView({
        image: "http://myhotelsapp.com/hotel/uploads/food/" + detail[i].image,
        height: "100%",
        width: "26%" }));



      tableRow.getChildren()[0].add(Ti.UI.createLabel({
        top: 10 * Alloy.Globals.scaleFactor,
        height: 20 * Alloy.Globals.scaleFactor,
        Color: 'black',
        ellipsize: Titanium.UI.TEXT_ELLIPSIZE_TRUNCATE_END,
        text: detail[i].title,
        maxLines: 1,
        font: {
          fontSize: 16 * Alloy.Globals.scaleFactor,
          fontFamily: "Roboto-Bold" } }));




      tableRow.getChildren()[0].add(Ti.UI.createLabel({
        top: 40 * Alloy.Globals.scaleFactor,
        height: 70 * Alloy.Globals.scaleFactor,
        Color: 'black',
        ellipsize: Titanium.UI.TEXT_ELLIPSIZE_TRUNCATE_END,
        text: detail[i].description,
        font: {
          fontSize: 13 * Alloy.Globals.scaleFactor,
          fontFamily: "Roboto-Light" } }));




      tableRow.getChildren()[0].add(Ti.UI.createLabel({
        top: 120 * Alloy.Globals.scaleFactor,
        Color: 'black',

        ellipsize: Titanium.UI.TEXT_ELLIPSIZE_TRUNCATE_END,
        text: "$. " + detail[i].price,
        maxLines: 1,
        font: {
          fontSize: 11 * Alloy.Globals.scaleFactor,
          fontFamily: "Roboto-Bold" } }));





      var qty = Alloy.Globals.langConvert("quantity") + ". " + detail[i].qty;
      tableRow.getChildren()[0].add(Ti.UI.createLabel({
        top: 120 * Alloy.Globals.scaleFactor,
        Color: 'black',

        ellipsize: Titanium.UI.TEXT_ELLIPSIZE_TRUNCATE_END,
        text: qty,
        maxLines: 1,
        font: {
          fontSize: 11 * Alloy.Globals.scaleFactor,
          fontFamily: "Roboto-Bold" } }));




      if (lang == 'ar') {
        tableRow.getChildren()[0].getChildren()[0].right = 0;
        tableRow.getChildren()[0].getChildren()[1].right = "30%";
        tableRow.getChildren()[0].getChildren()[1].left = 5;
        tableRow.getChildren()[0].getChildren()[1].textAlign = "right";
        tableRow.getChildren()[0].getChildren()[2].right = "30%";
        tableRow.getChildren()[0].getChildren()[2].left = 5;
        tableRow.getChildren()[0].getChildren()[2].textAlign = "right";
        tableRow.getChildren()[0].getChildren()[3].right = "30%";
        tableRow.getChildren()[0].getChildren()[3].textAlign = "right";
        tableRow.getChildren()[0].getChildren()[4].left = 5;
        tableRow.getChildren()[0].getChildren()[4].textAlign = "left";
      } else {

        tableRow.getChildren()[0].getChildren()[0].left = 0;
        tableRow.getChildren()[0].getChildren()[1].left = "30%";
        tableRow.getChildren()[0].getChildren()[1].right = 5;
        tableRow.getChildren()[0].getChildren()[1].textAlign = "left";
        tableRow.getChildren()[0].getChildren()[2].left = "30%";
        tableRow.getChildren()[0].getChildren()[2].right = 5;
        tableRow.getChildren()[0].getChildren()[2].textAlign = "left";
        tableRow.getChildren()[0].getChildren()[3].left = "30%";
        tableRow.getChildren()[0].getChildren()[3].textAlign = "left";
        tableRow.getChildren()[0].getChildren()[4].right = 5;
        tableRow.getChildren()[0].getChildren()[4].textAlign = "right";
      }
      tableData.push(tableRow);
    }
    $.cartTableView.setData(tableData);
  };

  function openFunc() {
    mycartService();
  }

  function mycartService() {

    if (Ti.Network.online) {
      Alloy.Globals.LoadingScreen.open();
      Communicator.get("http://myhotelsapp.com/api/api.php?action=VisitorCart&" + "language=" + Ti.App.Properties.getString("locale") + "&hotel_id=" + Ti.App.Properties.getString("hotel_id") + "&visitor_code=" + Ti.App.Properties.getString("visitor_code"), mycartServiceCallback);
      Ti.API.info('URL : ' + "http://myhotelsapp.com/api/api.php?action=AboutUs&" + "language=" + Ti.App.Properties.getString("locale") + "&hotel_id=" + Ti.App.Properties.getString("hotel_id"));
    } else {
      Alloy.Globals.Alert(Alloy.Globals.langConvert("internat_connection_message"));
    }
  }

  function mycartServiceCallback(e) {
    Ti.API.info("mycartServiceCallback Callback response : " + JSON.stringify(e));
    if (e.success) {
      try {

        var response = JSON.parse(e.response);

        if (response != null) {
          Ti.API.info('response.action_success = ' + JSON.stringify(response));
          if (response.success == '1') {
            Alloy.Globals.createNewsRow(response["Cart details"]);
          } else {
            Alloy.Globals.Alert(response.msg);
          }
        } else {
          Alloy.Globals.Alert(Alloy.Globals.Constants.MSG_NO_DATA);
        }
      } catch (e) {
        Ti.API.info('Error social Login List :: ' + e.message);
      }
    } else {
      Alloy.Globals.Alert(Alloy.Globals.langConvert("network_validation"));
    }

    Alloy.Globals.LoadingScreen.close();
  }





  __defers['$.__views.MyCart!open!openFunc'] && $.addListener($.__views.MyCart, 'open', openFunc);



  _.extend($, exports);
}

module.exports = Controller;