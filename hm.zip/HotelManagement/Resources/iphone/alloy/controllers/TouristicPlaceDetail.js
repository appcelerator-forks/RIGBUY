var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
  var arg = null;
  if (obj) {
    arg = obj[key] || null;
    delete obj[key];
  }
  return arg;
}

function Controller() {

  require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
  this.__controllerPath = 'TouristicPlaceDetail';
  this.args = arguments[0] || {};

  if (arguments[0]) {
    var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
    var $model = __processArg(arguments[0], '$model');
    var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
  }
  var $ = this;
  var exports = {};
  var __defers = {};







  $.__views.TouristicPlaceDetail = Ti.UI.createWindow(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    Alloy.deepExtend(true, o, { backButtonTitle: "", backButtonTitleImage: "none", id: "TouristicPlaceDetail" });
    return o;
  }());

  $.__views.TouristicPlaceDetail && $.addTopLevelView($.__views.TouristicPlaceDetail);
  $.__views.__alloyId31 = Ti.UI.createScrollView(
  { backgroundColor: "black", layout: "vertical", id: "__alloyId31" });

  $.__views.TouristicPlaceDetail.add($.__views.__alloyId31);
  $.__views.tourImage = Ti.UI.createImageView(
  { id: "tourImage", top: "25%", height: "45%", width: "100%", image: "http://www.lorempixel.com/700/600/" });

  $.__views.__alloyId31.add($.__views.tourImage);
  $.__views.descLbl = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { id: "descLbl", top: "10%", width: "96%", color: "white", textAlign: "justify" });
    return o;
  }());

  $.__views.__alloyId31.add($.__views.descLbl);
  exports.destroy = function () {};




  _.extend($, $.__views);



  var args = $.args;
  $.descLbl.font = {
    fontSize: 13 * Alloy.Globals.scaleFactor };

  $.descLbl.text = args.description;
  $.tourImage.image = "http://myhotelsapp.com/hotel/uploads/places/" + args.image;


  var tableData = [];

  var lang = Titanium.App.Properties.getString('locale');

  if (true) {

    var btnVW = Titanium.UI.createView({
      width: 40,
      height: 40 });



    var toggleBtn = Titanium.UI.createButton({
      backgroundImage: "none" });

    btnVW.add(toggleBtn);

    Ti.API.info('2222');
    if (lang == "ar") {
      toggleBtn.right = 0;
      toggleBtn.image = "/images/barrow_ar.png";
    } else {
      toggleBtn.left = 0;
      toggleBtn.image = "/images/back.png";
    }

    var notificationBtn = Titanium.UI.createButton({
      backgroundImage: "none",
      image: "/images/notification.png",
      visible: true });



    $.TouristicPlaceDetail.title = args.title;
    if (lang == "ar") {
      $.TouristicPlaceDetail.leftNavButton = notificationBtn;
      $.TouristicPlaceDetail.rightNavButton = btnVW;
    } else {
      $.TouristicPlaceDetail.leftNavButton = btnVW;
      $.TouristicPlaceDetail.rightNavButton = notificationBtn;
    }
    btnVW.addEventListener('click', function (e) {
      $.TouristicPlaceDetail.close();
    });
    notificationBtn.addEventListener("click", function (e) {

      var mycart = Alloy.createController("MyCart").getView();
      Alloy.Globals.navWin.openWindow(mycart);
      mycart.oldWin = $.TouristicPlaceDetail;
      Alloy.Globals.currentWindow = mycart;
    });
  }









  _.extend($, exports);
}

module.exports = Controller;