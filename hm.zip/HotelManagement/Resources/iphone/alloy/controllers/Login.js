var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
  var arg = null;
  if (obj) {
    arg = obj[key] || null;
    delete obj[key];
  }
  return arg;
}

function Controller() {

  require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
  this.__controllerPath = 'Login';
  this.args = arguments[0] || {};

  if (arguments[0]) {
    var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
    var $model = __processArg(arguments[0], '$model');
    var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
  }
  var $ = this;
  var exports = {};
  var __defers = {};







  $.__views.__alloyId18 = Ti.UI.createWindow(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    Alloy.deepExtend(true, o, { barColor: "#dc1474", id: "__alloyId18" });
    return o;
  }());

  winClickFunc ? $.addListener($.__views.__alloyId18, 'click', winClickFunc) : __defers['$.__views.__alloyId18!click!winClickFunc'] = true;$.__views.__alloyId20 = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { text: 'HotelManagment', color: "white", id: "__alloyId20" });
    return o;
  }());

  $.__views.__alloyId18.titleControl = $.__views.__alloyId20;$.__views.__alloyId21 = Ti.UI.createScrollView(
  { id: "__alloyId21" });

  $.__views.__alloyId18.add($.__views.__alloyId21);
  $.__views.__alloyId22 = Ti.UI.createImageView(
  { image: "/images/logoLogin.png", top: "15.94%", id: "__alloyId22" });

  $.__views.__alloyId21.add($.__views.__alloyId22);
  $.__views.registrationVW = Ti.UI.createView(
  { id: "registrationVW", width: "92%", top: "52%", height: "10%" });

  $.__views.__alloyId21.add($.__views.registrationVW);
  $.__views.__alloyId23 = Ti.UI.createView(
  { backgroundColor: "#858484", width: "100%", bottom: 0, height: 1, id: "__alloyId23" });

  $.__views.registrationVW.add($.__views.__alloyId23);
  $.__views.registrationLbl = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { text: 'Registration Number', id: "registrationLbl", top: 0, left: 0, opacity: 0, color: "#dc1474" });
    return o;
  }());

  $.__views.registrationVW.add($.__views.registrationLbl);
  $.__views.registrationTF = Ti.UI.createTextField(
  { id: "registrationTF", returnKeyType: Ti.UI.RETURNKEY_NEXT, name: "tf", backgroundColor: "white", bottom: 1, height: "48%", left: 0, width: "100%", hintText: "Registration Number" });

  $.__views.registrationVW.add($.__views.registrationTF);
  registrationReturnFunc ? $.addListener($.__views.registrationTF, 'return', registrationReturnFunc) : __defers['$.__views.registrationTF!return!registrationReturnFunc'] = true;changeRegistrationFunc ? $.addListener($.__views.registrationTF, 'change', changeRegistrationFunc) : __defers['$.__views.registrationTF!change!changeRegistrationFunc'] = true;$.__views.roomVW = Ti.UI.createView(
  { id: "roomVW", width: "92%", top: "64%", height: "10%" });

  $.__views.__alloyId21.add($.__views.roomVW);
  $.__views.__alloyId24 = Ti.UI.createView(
  { backgroundColor: "#858484", width: "100%", bottom: 0, height: 1, zIndex: 1, id: "__alloyId24" });

  $.__views.roomVW.add($.__views.__alloyId24);
  $.__views.roomLbl = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { text: 'Room Number', id: "roomLbl", top: 0, left: 0, opacity: 0, color: "#dc1474" });
    return o;
  }());

  $.__views.roomVW.add($.__views.roomLbl);
  $.__views.roomTF = Ti.UI.createTextField(
  { id: "roomTF", returnKeyType: Ti.UI.RETURNKEY_DONE, name: "tf", passwordMask: true, backgroundColor: "white", bottom: 1, height: "48%", left: 0, width: "90%", hintText: "Room Number" });

  $.__views.roomVW.add($.__views.roomTF);
  changeRoomFunc ? $.addListener($.__views.roomTF, 'change', changeRoomFunc) : __defers['$.__views.roomTF!change!changeRoomFunc'] = true;$.__views.eyeBtn = Ti.UI.createButton(
  { id: "eyeBtn", backgroundImage: "none", image: "/images/eye.png", bottom: 1, right: 0, height: "48%", width: "10%", zIndex: 19 });

  $.__views.roomVW.add($.__views.eyeBtn);
  maskHideFunc ? $.addListener($.__views.eyeBtn, 'click', maskHideFunc) : __defers['$.__views.eyeBtn!click!maskHideFunc'] = true;$.__views.loginBtn = Ti.UI.createButton(
  { color: "white", font: { fontSize: 14 }, id: "loginBtn", title: "Login", width: "92%", top: "80%", height: "7%", backgroundColor: "#dc0474" });

  $.__views.__alloyId21.add($.__views.loginBtn);
  loginFunc ? $.addListener($.__views.loginBtn, 'click', loginFunc) : __defers['$.__views.loginBtn!click!loginFunc'] = true;$.__views.Login = Ti.UI.iOS.createNavigationWindow(
  { window: $.__views.__alloyId18, id: "Login" });

  $.__views.Login && $.addTopLevelView($.__views.Login);
  exports.destroy = function () {};




  _.extend($, $.__views);



  var args = $.args;
  Alloy.Globals.loginObj = $.Login;
  Alloy.Globals.loadingLbl.text = "Please wait...";

  var Communicator = Alloy.Globals.Communicator;
  var DOMAIN_URL = Alloy.Globals.Constants.DOMAIN_URL;

  $.registrationLbl.font = {
    fontSize: 13 * Alloy.Globals.scaleFactor,
    fontWeight: 'bold' };

  $.registrationTF.font = {
    fontSize: 16 * Alloy.Globals.scaleFactor,
    fontFamily: "HelveticaNeue-Regular" };

  $.roomLbl.font = {
    fontSize: 13 * Alloy.Globals.scaleFactor,
    fontWeight: 'bold' };

  $.roomTF.font = {
    fontSize: 16 * Alloy.Globals.scaleFactor,
    fontFamily: "HelveticaNeue-Regular" };

  function winClickFunc(e) {
    if (e.source.name != "tf") {
      $.registrationTF.blur();
      $.roomTF.blur();
    }
  }

  function registrationReturnFunc(e) {
    $.roomTF.focus();
  }
  var flag = true;
  function maskHideFunc(e) {

    if (flag) {

      $.roomTF.passwordMask = false;
      $.eyeBtn.image = "/images/eyeClose.png";
      flag = false;
    } else {
      $.eyeBtn.image = "/images/eye.png";
      $.roomTF.passwordMask = true;
      flag = true;
    }
  }

  function loginFunc(e) {
    if ($.loginBtn.focusable == false) {
      return;
    }
    $.loginBtn.focusable == false;
    if ($.registrationTF.value != null && $.registrationTF.value.trim().length > 0) {

      if ($.roomTF.value != null && $.roomTF.value.trim().length > 0) {
        loginService();
      } else {
        Alloy.Globals.Alert("Please enter valid room number");
      }
    } else {
      Alloy.Globals.Alert("Please enter valid registration number");
    }
    setTimeout(function (e) {
      $.loginBtn.focusable == true;
    }, 1000);
  }

  function changeRegistrationFunc(e) {
    if (e.source.value.length > 0) {
      $.registrationLbl.animate({
        duration: 500,
        opacity: 1 });

    } else {
      $.registrationLbl.animate({
        duration: 500,
        opacity: 0 });

    }
  }

  function changeRoomFunc(e) {
    if (e.source.value.length > 0) {
      $.roomLbl.animate({
        duration: 500,
        opacity: 1 });

    } else {
      $.roomLbl.animate({
        duration: 500,
        opacity: 0 });

    }
  }

  function loginService() {

    if (Ti.Network.online) {
      Alloy.Globals.LoadingScreen.open();
      Communicator.get("http://myhotelsapp.com/api/api.php?action=UserLogin&" + "registartion_number=" + $.registrationTF.value + "&room_number=" + $.roomTF.value + "&device_type=ios" + "&device_id=" + Alloy.Globals.deviceToken, loginServiceCallback);
      Ti.API.info('URL : ' + "http://myhotelsapp.com/api/api.php?action=UserLogin&" + "registartion_number=" + $.registrationTF.value + "&room_number=" + $.roomTF.value + "&device_type=ios" + "&device_id=" + Alloy.Globals.deviceToken);
    } else {
      $.loginBtn.focusable = true;
      Alloy.Globals.Alert(Alloy.Globals.langConvert("internat_connection_message"));
    }
  }





  function loginServiceCallback(e) {
    Ti.API.info("loginServiceCallback response : " + JSON.stringify(e));
    if (e.success) {
      try {
        Ti.API.info('response ' + e.response);
        var response = JSON.parse(e.response);

        if (response != null) {

          if (response.success == '1') {

            Ti.App.Properties.setString("hotel_id", response.userdetails.hotel_id);
            Ti.App.Properties.setString("visitor_code", response.userdetails.visitor_code);
            Ti.App.Properties.setString("locale", response.userdetails.language.toLowerCase());
            Ti.App.Properties.setString("room_number", response.userdetails.room_number);
            Alloy.Globals.openHome(response.userdetails, $.Login, $.loginBtn);
          } else {
            Alloy.Globals.Alert(response.msg);
            $.loginBtn.focusable = true;
          }
        } else {
          Alloy.Globals.Alert(Alloy.Globals.Constants.MSG_NO_DATA);
          $.loginBtn.focusable = true;

        }
      } catch (e) {
        Ti.API.info('Error social Login List :: ' + e.message);
        $.loginBtn.focusable = true;

      }
    } else {
      Alloy.Globals.Alert(Alloy.Globals.langConvert("network_validation"));
      $.loginBtn.focusable = true;

    }
    $.loginBtn.focusable = true;
    Alloy.Globals.LoadingScreen.close();
  }





  __defers['$.__views.__alloyId18!click!winClickFunc'] && $.addListener($.__views.__alloyId18, 'click', winClickFunc);__defers['$.__views.registrationTF!return!registrationReturnFunc'] && $.addListener($.__views.registrationTF, 'return', registrationReturnFunc);__defers['$.__views.registrationTF!change!changeRegistrationFunc'] && $.addListener($.__views.registrationTF, 'change', changeRegistrationFunc);__defers['$.__views.roomTF!change!changeRoomFunc'] && $.addListener($.__views.roomTF, 'change', changeRoomFunc);__defers['$.__views.eyeBtn!click!maskHideFunc'] && $.addListener($.__views.eyeBtn, 'click', maskHideFunc);__defers['$.__views.loginBtn!click!loginFunc'] && $.addListener($.__views.loginBtn, 'click', loginFunc);



  _.extend($, exports);
}

module.exports = Controller;