var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
  var arg = null;
  if (obj) {
    arg = obj[key] || null;
    delete obj[key];
  }
  return arg;
}

function Controller() {

  require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
  this.__controllerPath = 'Home';
  this.args = arguments[0] || {};

  if (arguments[0]) {
    var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
    var $model = __processArg(arguments[0], '$model');
    var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
  }
  var $ = this;
  var exports = {};
  var __defers = {};







  if (true) {
    $.__views.leftWindow = Ti.UI.createWindow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
      Alloy.deepExtend(true, o, { id: "leftWindow", name: "homewin", left: 0, backgroundColor: "#dc0474", layout: "vertical" });
      return o;
    }());

    $.__views.leftWindow && $.addTopLevelView($.__views.leftWindow);
    $.__views.__alloyId4 = Ti.UI.createView(
    { height: 20, backgroundColor: "#dc0474", top: 0, id: "__alloyId4" });

    $.__views.leftWindow.add($.__views.__alloyId4);
    $.__views.topview = Ti.UI.createView(
    { id: "topview", backgroundColor: "white", top: 0, left: 0, height: "30%" });

    $.__views.leftWindow.add($.__views.topview);
    $.__views.__alloyId5 = Ti.UI.createImageView(
    { height: Ti.UI.FILL, width: Ti.UI.FILL, image: "/images/header.png", id: "__alloyId5" });

    $.__views.topview.add($.__views.__alloyId5);
    $.__views.welcomeLbl = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      Alloy.deepExtend(true, o, { left: 0, textAlign: "left" });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 22, fontFamily: "Roboto-Bold", fontWeight: "bold" }, height: Ti.UI.SIZE, ellipsize: true });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 25, fontFamily: "Roboto-Bold", fontWeight: "bold" }, height: Ti.UI.SIZE, ellipsize: true });
      Alloy.deepExtend(true, o, { text: 'Welcome', id: "welcomeLbl", bottom: 20, left: "5%", textAlign: "center", color: "#fff" });
      return o;
    }());

    $.__views.topview.add($.__views.welcomeLbl);
    $.__views.__alloyId6 = Ti.UI.createView(
    { height: "0.6dp", width: Ti.UI.FILL, backgroundColor: "#DCDCDC", id: "__alloyId6" });

    $.__views.leftWindow.add($.__views.__alloyId6);
    $.__views.__alloyId7 = Ti.UI.createView(
    { backgroundColor: "#dc0474", top: 0, id: "__alloyId7" });

    $.__views.leftWindow.add($.__views.__alloyId7);
    $.__views.__alloyId9 = Ti.UI.createView(
    { height: "0.6dp", backgroundColor: "transparent", id: "__alloyId9" });

    var __alloyId10 = [];$.__views.homeRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "homeRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId10.push($.__views.homeRow);$.__views.homeimge = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "homeimge", image: "/images/home.png" });
      return o;
    }());

    $.__views.homeRow.add($.__views.homeimge);
    $.__views.homeRowLbl = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { text: 'Home', touchEnabled: false, id: "homeRowLbl", color: "white", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.homeRow.add($.__views.homeRowLbl);
    $.__views.foodMenuRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "foodMenuRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId10.push($.__views.foodMenuRow);$.__views.foodMenuimge = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "foodMenuimge", image: "/images/food.png" });
      return o;
    }());

    $.__views.foodMenuRow.add($.__views.foodMenuimge);
    $.__views.foodMenuLbl = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { text: 'Food Menu', touchEnabled: false, id: "foodMenuLbl", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.foodMenuRow.add($.__views.foodMenuLbl);
    $.__views.hotelActivityRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "hotelActivityRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId10.push($.__views.hotelActivityRow);$.__views.hotelActivityimge = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "hotelActivityimge", image: "/images/hotelActivity.png" });
      return o;
    }());

    $.__views.hotelActivityRow.add($.__views.hotelActivityimge);
    $.__views.hotelActivityLbl = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { text: 'Hotel Activity', touchEnabled: false, id: "hotelActivityLbl", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.hotelActivityRow.add($.__views.hotelActivityLbl);
    $.__views.touristicPlaceRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "touristicPlaceRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId10.push($.__views.touristicPlaceRow);$.__views.touristicPlaceimge = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "touristicPlaceimge", image: "/images/tour.png" });
      return o;
    }());

    $.__views.touristicPlaceRow.add($.__views.touristicPlaceimge);
    $.__views.touristicPlaceLbl = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { text: 'Touristic Places', touchEnabled: false, id: "touristicPlaceLbl", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.touristicPlaceRow.add($.__views.touristicPlaceLbl);
    $.__views.aboutUsRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "aboutUsRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId10.push($.__views.aboutUsRow);$.__views.aboutUsimge = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "aboutUsimge", image: "/images/aboutUs.png" });
      return o;
    }());

    $.__views.aboutUsRow.add($.__views.aboutUsimge);
    $.__views.aboutUsLbl = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { text: 'About Us', touchEnabled: false, id: "aboutUsLbl", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.aboutUsRow.add($.__views.aboutUsLbl);
    $.__views.rateUsRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "rateUsRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId10.push($.__views.rateUsRow);$.__views.rateUsimge = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "rateUsimge", image: "/images/rateUs.png" });
      return o;
    }());

    $.__views.rateUsRow.add($.__views.rateUsimge);
    $.__views.rateUsLbl = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { text: 'Rate Us', touchEnabled: false, id: "rateUsLbl", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.rateUsRow.add($.__views.rateUsLbl);
    $.__views.logoutRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "logoutRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId10.push($.__views.logoutRow);$.__views.logoutimge = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { left: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "logoutimge", image: "/images/logout.png" });
      return o;
    }());

    $.__views.logoutRow.add($.__views.logoutimge);
    $.__views.logoutLbl = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, left: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { text: 'Logout', touchEnabled: false, id: "logoutLbl", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.logoutRow.add($.__views.logoutLbl);
    $.__views.rightTable = Ti.UI.createTableView(
    { separatorInsets: { left: 0, right: 0 }, data: __alloyId10, footerView: $.__views.__alloyId9, id: "rightTable", separatorColor: "transparent", backgroundColor: "#dc0474", focusable: true, scrollable: false });

    $.__views.__alloyId7.add($.__views.rightTable);
    leftMenuOptionSelected ? $.addListener($.__views.rightTable, 'click', leftMenuOptionSelected) : __defers['$.__views.rightTable!click!leftMenuOptionSelected'] = true;}
  if (true) {
    $.__views.rightWindow = Ti.UI.createWindow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
      Alloy.deepExtend(true, o, { id: "rightWindow", name: "homewin", backgroundColor: "#dc0474", layout: "vertical" });
      return o;
    }());

    $.__views.rightWindow && $.addTopLevelView($.__views.rightWindow);
    $.__views.__alloyId11 = Ti.UI.createView(
    { height: 20, backgroundColor: "#dc0474", top: 0, id: "__alloyId11" });

    $.__views.rightWindow.add($.__views.__alloyId11);
    $.__views.topview1 = Ti.UI.createView(
    { id: "topview1", top: 20, right: 0, height: "30%" });

    $.__views.rightWindow.add($.__views.topview1);
    $.__views.__alloyId12 = Ti.UI.createImageView(
    { height: Ti.UI.FILL, width: Ti.UI.FILL, image: "/images/header.png", id: "__alloyId12" });

    $.__views.topview1.add($.__views.__alloyId12);
    $.__views.welcomeLbl1 = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 20, fontFamily: "Roboto-Regular" }, height: Ti.UI.SIZE, ellipsize: true });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 22, fontFamily: "Roboto-Regular" }, height: Ti.UI.SIZE, ellipsize: true });
      Alloy.deepExtend(true, o, { text: 'Welcome', id: "welcomeLbl1", bottom: 30, right: "5%", textAlign: "center", color: "#fff" });
      return o;
    }());

    $.__views.topview1.add($.__views.welcomeLbl1);
    $.__views.__alloyId13 = Ti.UI.createView(
    { height: "0.6dp", width: Ti.UI.FILL, backgroundColor: "#DCDCDC", id: "__alloyId13" });

    $.__views.rightWindow.add($.__views.__alloyId13);
    $.__views.__alloyId15 = Ti.UI.createView(
    { height: "0.6dp", backgroundColor: "transparent", id: "__alloyId15" });

    var __alloyId16 = [];$.__views.homeRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "homeRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId16.push($.__views.homeRow);$.__views.homeimge1 = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "homeimge1", image: "/images/home.png" });
      return o;
    }());

    $.__views.homeRow.add($.__views.homeimge1);
    $.__views.homeRowLbl1 = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { touchEnabled: false, id: "homeRowLbl1", color: "white", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.homeRow.add($.__views.homeRowLbl1);
    $.__views.foodMenuRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "foodMenuRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId16.push($.__views.foodMenuRow);$.__views.foodMenuimge1 = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "foodMenuimge1", image: "/images/food.png" });
      return o;
    }());

    $.__views.foodMenuRow.add($.__views.foodMenuimge1);
    $.__views.foodMenuLbl1 = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { touchEnabled: false, id: "foodMenuLbl1", color: "white", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.foodMenuRow.add($.__views.foodMenuLbl1);
    $.__views.hotelActivityRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "hotelActivityRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId16.push($.__views.hotelActivityRow);$.__views.hotelActivityimge1 = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "hotelActivityimge1", image: "/images/hotelActivity.png" });
      return o;
    }());

    $.__views.hotelActivityRow.add($.__views.hotelActivityimge1);
    $.__views.hotelActivityLbl1 = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { touchEnabled: false, id: "hotelActivityLbl1", color: "white", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.hotelActivityRow.add($.__views.hotelActivityLbl1);
    $.__views.touristicPlaceRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "touristicPlaceRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId16.push($.__views.touristicPlaceRow);$.__views.touristicPlaceimge1 = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "touristicPlaceimge1", image: "/images/tour.png" });
      return o;
    }());

    $.__views.touristicPlaceRow.add($.__views.touristicPlaceimge1);
    $.__views.touristicPlaceLbl1 = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { touchEnabled: false, id: "touristicPlaceLbl1", color: "white", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.touristicPlaceRow.add($.__views.touristicPlaceLbl1);
    $.__views.aboutUsRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "aboutUsRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId16.push($.__views.aboutUsRow);$.__views.aboutUsimge1 = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "aboutUsimge1", image: "/images/aboutUs.png" });
      return o;
    }());

    $.__views.aboutUsRow.add($.__views.aboutUsimge1);
    $.__views.aboutUsLbl1 = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { touchEnabled: false, id: "aboutUsLbl1", color: "white", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.aboutUsRow.add($.__views.aboutUsLbl1);
    $.__views.rateUsRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "rateUsRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId16.push($.__views.rateUsRow);$.__views.rateUsimge1 = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "rateUsimge1", image: "/images/rateUs.png" });
      return o;
    }());

    $.__views.rateUsRow.add($.__views.rateUsimge1);
    $.__views.rateUsLbl1 = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { touchEnabled: false, id: "rateUsLbl1", color: "white", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.rateUsRow.add($.__views.rateUsLbl1);
    $.__views.logoutRow = Ti.UI.createTableViewRow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { height: 40, color: "white" });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { height: 50, color: "white" });
      Alloy.deepExtend(true, o, { id: "logoutRow", width: "100%", selectedBackgroundColor: "#993f6c" });
      return o;
    }());

    __alloyId16.push($.__views.logoutRow);$.__views.logoutimge1 = Ti.UI.createImageView(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      if (Alloy.isTablet) Alloy.deepExtend(true, o, { right: Alloy.Globals.padding });
      Alloy.deepExtend(true, o, { id: "logoutimge1", image: "/images/logout.png" });
      return o;
    }());

    $.__views.logoutRow.add($.__views.logoutimge1);
    $.__views.logoutLbl1 = Ti.UI.createLabel(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 13, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { color: "#fff", font: { fontSize: 16, fontFamily: "Roboto-Regular" }, right: Alloy.Globals.padding1 });
      Alloy.deepExtend(true, o, { touchEnabled: false, id: "logoutLbl1", color: "white", width: Titanium.UI.SIZE, focusable: false });
      return o;
    }());

    $.__views.logoutRow.add($.__views.logoutLbl1);
    $.__views.rightTable = Ti.UI.createTableView(
    { separatorInsets: { left: 0, right: 0 }, data: __alloyId16, footerView: $.__views.__alloyId15, id: "rightTable", backgroundColor: "#dc0474", separatorColor: "transparent", focusable: true });

    $.__views.rightWindow.add($.__views.rightTable);
    leftMenuOptionSelected ? $.addListener($.__views.rightTable, 'click', leftMenuOptionSelected) : __defers['$.__views.rightTable!click!leftMenuOptionSelected'] = true;}
  if (true) {
    $.__views.homeWin = Ti.UI.createWindow(
    function () {
      var o = {};
      if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
      if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
      Alloy.deepExtend(true, o, { titleid: "home_title_home", font: { fontSize: 14, fontFamily: "Roboto", fontType: "Regular", fontStyle: "Sharp" }, id: "homeWin", name: "homewin", backgroundColor: "white" });
      return o;
    }());

    openFun ? $.addListener($.__views.homeWin, 'open', openFun) : __defers['$.__views.homeWin!open!openFun'] = true;$.__views.containerVW = Ti.UI.createView(
    { id: "containerVW", opacity: 0 });

    $.__views.homeWin.add($.__views.containerVW);
    $.__views.engView = Ti.UI.createView(
    { id: "engView", visible: true, layout: "vertical" });

    $.__views.containerVW.add($.__views.engView);
    $.__views.fg = Alloy.createWidget('com.prodz.tiflexigrid', 'widget', { id: "fg", __parentSymbol: $.__views.engView });
    $.__views.fg.setParent($.__views.engView);
    $.__views.navWindow = Ti.UI.iOS.createNavigationWindow(
    { window: $.__views.homeWin, id: "navWindow", bubbleParent: false });

    $.__views.navWindow && $.addTopLevelView($.__views.navWindow);
  }
  exports.destroy = function () {};




  _.extend($, $.__views);



  var args = $.args;
  Alloy.Globals.logedin = true;
  Ti.UI.iOS.setAppBadge(0);
  Alloy.Globals.profileData = args;



  var lang = Titanium.App.Properties.getString('locale');


  var Communicator = Alloy.Globals.Communicator;
  var DOMAIN_URL = Alloy.Globals.Constants.DOMAIN_URL;




  var focus = true;






  Alloy.Globals.navWin = $.navWindow;
  Alloy.Globals.mainVW = $.mainVW;




  String.prototype.capitalize = function () {
    try {
      return this.charAt(0).toUpperCase() + this.slice(1);
    } catch (e) {
      Ti.API.info('Error Fun : capitalize ');
    }
  };

  $.fg.init({
    columns: 2,
    space: 0,
    gridBackgroundColor: '#fff',
    itemHeightDelta: 0,
    itemBackgroundColor: '#eee',
    itemBorderColor: 'transparent',
    itemBorderWidth: 0,
    itemBorderRadius: 0 });


  var items = [];
  var sample_data = [];
  if (lang == "ar") {
    Alloy.Globals.languageAr = true;
    Alloy.Globals.languageEn = false;
    sample_data = [{
      title: Alloy.Globals.langConvert("hotel_activity"),
      image: '/images/image_2.jpg',
      name: "ha" },
    {
      title: Alloy.Globals.langConvert("food_menu"),
      image: '/images/image_1.jpg',
      name: "fm" },
    {
      title: Alloy.Globals.langConvert("about_us"),
      image: '/images/image_4.jpg',
      name: "au" },
    {
      title: Alloy.Globals.langConvert("touristic_places"),
      image: '/images/image_3.jpg',
      name: "tp" },
    {
      title: "",
      image: 'http://www.lorempixel.com/600/600/',
      name: "white" },
    {
      title: Alloy.Globals.langConvert("write_to_us"),
      image: '/images/image_5.jpg',
      name: "wu" }];

    $.welcomeLbl1.text = Alloy.Globals.langConvert("welcome") + " " + Ti.App.Properties.getString("room_number");
    $.homeRowLbl1.text = Alloy.Globals.langConvert("home");
    $.foodMenuLbl1.text = Alloy.Globals.langConvert("hotel_activity");
    $.hotelActivityLbl1.text = Alloy.Globals.langConvert("hotel_activity");
    $.foodMenuLbl1.text = Alloy.Globals.langConvert("food_menu");
    $.aboutUsLbl1.text = Alloy.Globals.langConvert("about_us");
    $.touristicPlaceLbl1.text = Alloy.Globals.langConvert("touristic_places");
    $.rateUsLbl1.text = Alloy.Globals.langConvert("write_to_us");
    $.logoutLbl1.text = Alloy.Globals.langConvert("logout");
    Alloy.Globals.loadingLbl.text = Alloy.Globals.langConvert("loading");
  } else {
    Alloy.Globals.loadingLbl.text = Alloy.Globals.langConvert("loading");
    Alloy.Globals.languageAr = false;
    Alloy.Globals.languageEn = true;
    $.homeRowLbl.text = Alloy.Globals.langConvert("home");
    $.logoutLbl.text = Alloy.Globals.langConvert("logout");
    $.welcomeLbl.text = Alloy.Globals.langConvert("welcome") + " " + Ti.App.Properties.getString("room_number");
    $.foodMenuLbl.text = Alloy.Globals.langConvert("hotel_activity");
    $.hotelActivityLbl.text = Alloy.Globals.langConvert("hotel_activity");
    $.foodMenuLbl.text = Alloy.Globals.langConvert("food_menu");
    $.aboutUsLbl.text = Alloy.Globals.langConvert("about_us");
    $.touristicPlaceLbl.text = Alloy.Globals.langConvert("touristic_places");
    $.rateUsLbl.text = Alloy.Globals.langConvert("write_to_us");
    sample_data = [{
      title: Alloy.Globals.langConvert("food_menu"),
      image: '/images/image_1.jpg',

      name: "fm" },
    {
      title: Alloy.Globals.langConvert("hotel_activity"),
      image: '/images/image_2.jpg',
      name: "ha" },
    {
      title: Alloy.Globals.langConvert("touristic_places"),
      image: '/images/image_3.jpg',
      name: "tp" },
    {
      title: Alloy.Globals.langConvert("about_us"),
      image: '/images/image_4.jpg',
      name: "au" },
    {
      title: Alloy.Globals.langConvert("write_to_us"),
      image: '/images/image_5.jpg',
      name: "wu" }];

  }

  renderHomeGrid(sample_data);
  function renderHomeGrid(sample_data) {
    items = [];
    for (var x = 0; x < sample_data.length; x++) {
      Ti.API.info('--------');

      var view = Ti.UI.createView({});

      if (lang == "ar") {
        if (x == 4) {
          view.backgroundColor = "white";
        } else {
          var img = Ti.UI.createImageView({
            image: sample_data[x].image,
            width: Ti.UI.FILL,
            height: Ti.UI.FILL });

          view.add(img);
          var titleVW = Ti.UI.createView({
            backgroundColor: "#dc0474",
            height: 40 * Alloy.Globals.scaleFactor,
            bottom: 0 });

          view.add(titleVW);
          var title = Ti.UI.createLabel({
            textAlign: "center",
            font: {
              fontSize: 13 * Alloy.Globals.scaleFactor },

            text: sample_data[x].title,
            color: "white" });

          titleVW.add(title);
        }
      } else {
        var img = Ti.UI.createImageView({
          image: sample_data[x].image,
          width: Ti.UI.FILL,
          height: Ti.UI.FILL });

        view.add(img);
        var titleVW = Ti.UI.createView({
          backgroundColor: "#dc0474",
          height: 40 * Alloy.Globals.scaleFactor,
          bottom: 0 });

        view.add(titleVW);
        var title = Ti.UI.createLabel({
          textAlign: "center",
          font: {
            fontSize: 13 * Alloy.Globals.scaleFactor },

          text: sample_data[x].title,
          color: "white" });

        titleVW.add(title);
      }


      var values = {
        title: sample_data[x].title,
        image: sample_data[x].image,
        name: sample_data[x].name };



      items.push({
        view: view,
        data: values });

    };
    $.fg.addGridItems(items);
    $.fg.setOnItemClick(function (e) {
      Ti.API.info('Data ' + e.source.data.name);
      if (e.source.data.name == "fm") {
        var regScreen = Alloy.createController("FoodMenu", "home").getView();
        Alloy.Globals.navWin.openWindow(regScreen);

        Alloy.Globals.currentWindow = regScreen;
      } else if (e.source.data.name == "ha") {
        var regScreen = Alloy.createController("HotelActivity", "home").getView();
        Alloy.Globals.navWin.openWindow(regScreen);

        Alloy.Globals.currentWindow = regScreen;
      } else if (e.source.data.name == "tp") {
        var regScreen = Alloy.createController("TouristicPlaces", "home").getView();
        Alloy.Globals.navWin.openWindow(regScreen);

        Alloy.Globals.currentWindow = regScreen;
      } else if (e.source.data.name == "au") {
        var regScreen = Alloy.createController("AboutUs", "home").getView();
        Alloy.Globals.navWin.openWindow(regScreen);

        Alloy.Globals.currentWindow = regScreen;
      } else if (e.source.data.name == "wu") {
        var regScreen = Alloy.createController("RateUs", "home").getView();
        Alloy.Globals.navWin.openWindow(regScreen);

        Alloy.Globals.currentWindow = regScreen;
      }
    });
  }




  if (true) {

    var toggleBtn = Titanium.UI.createButton({
      backgroundImage: "none",
      image: "/images/menu.png",
      visible: true });


    var notificationBtn = Titanium.UI.createButton({
      backgroundImage: "none",
      image: "/images/notification.png",
      visible: true });



    $.homeWin.title = Alloy.Globals.langConvert("home");
    if (lang == "ar") {
      $.homeWin.leftNavButton = notificationBtn;
      $.homeWin.rightNavButton = toggleBtn;
    } else {
      $.homeWin.leftNavButton = toggleBtn;
      $.homeWin.rightNavButton = notificationBtn;
    }

    toggleBtn.addEventListener('click', toggleLeftView);

    if (true) {
      $.topview.width = Alloy.Globals.homedrawerWidth + 30;
      $.topview1.width = Alloy.Globals.homedrawerWidth + 30;
    }

    notificationBtn.addEventListener("click", function (e) {

      var mycart = Alloy.createController("MyCart").getView();
      Alloy.Globals.navWin.openWindow(mycart);
      Alloy.Globals.currentWindow = mycart;
    });
  }




  Alloy.Globals.language = lang;




  function toggleLeftView() {

    if (lang == "ar") {
      Ti.API.info("langtoggle1 " + lang);
      Alloy.Globals.openRight();
    } else {
      Ti.API.info("langtoggle2 " + lang);
      Alloy.Globals.openLeft();
    }
  }




  function leftMenuOptionSelected(e) {

    if ($.rightTable.focusable == false) {
      return;
    }
    $.rightTable.focusable = false;
    if (e.index != 6) {
      Alloy.Globals.goToHome(Alloy.Globals.currentWindow);
    }

    Ti.API.info('Name1---------' + e.index + "  " + Alloy.Globals.currentWindow);
    switch (e.index) {
      case 0:





        Alloy.Globals.currentWindow = null;


        break;
      case 1:


        if (Ti.Network.online) {

          var regScreen = Alloy.createController("FoodMenu", "menu").getView();

          Alloy.Globals.navWin.openWindow(regScreen);



          Alloy.Globals.currentWindow = regScreen;
        } else {
          Alloy.Globals.Alert("Please check your internet connection and try again");
        }
        break;
      case 2:


        Ti.API.info('Name2---------2 ' + Alloy.Globals.currentWindow);

        if (Ti.Network.online) {
          var regScreen = Alloy.createController("HotelActivity", "menu").getView();

          Alloy.Globals.navWin.openWindow(regScreen);



          Alloy.Globals.currentWindow = regScreen;
        } else {
          Alloy.Globals.Alert(Alloy.Globals.langConvert("internat_connection_message"));


        }
        break;
      case 3:


        if (Ti.Network.online) {
          var regScreen = Alloy.createController("TouristicPlaces", "menu").getView();

          Alloy.Globals.navWin.openWindow(regScreen);



          Alloy.Globals.currentWindow = regScreen;
        } else {
          Alloy.Globals.Alert(Alloy.Globals.langConvert("internat_connection_message"));
        }

        break;
      case 4:


        if (Ti.Network.online) {
          var regScreen = Alloy.createController("AboutUs", "menu").getView();

          Alloy.Globals.navWin.openWindow(regScreen);



          Alloy.Globals.currentWindow = regScreen;
        } else {
          Alloy.Globals.Alert(Alloy.Globals.langConvert("internat_connection_message"));
        }

        break;
      case 5:


        if (Ti.Network.online) {
          var regScreen = Alloy.createController("RateUs", "menu").getView();

          Alloy.Globals.navWin.openWindow(regScreen);



          Alloy.Globals.currentWindow = regScreen;
        } else {
          Alloy.Globals.Alert(Alloy.Globals.langConvert("internat_connection_message"));
        }

        break;

      case 6:
        focus = true;
        $.rightTable.focusable = true;
        logout();

        break;}



    if (lang == "ar") {
      Alloy.Globals.openRight();
    } else {
      Alloy.Globals.openLeft();
    }

    setTimeout(function (e) {
      $.rightTable.focusable = true;
      focus = true;
    }, 500);
  }

  function logout() {
    if (true) {
      var dialog = Ti.UI.createAlertDialog({
        cancel: 1,
        buttonNames: [Alloy.Globals.langConvert("ok"), Alloy.Globals.langConvert("cancel")],
        message: Alloy.Globals.langConvert("logout_dialog") + "?",
        title: Alloy.Globals.langConvert("app_name") });

      dialog.addEventListener('click', function (e) {
        if (e.index === 0) {
          if (logoutInterval != null) {
            clearInterval(logoutInterval);
            logoutInterval = null;
          }
          if (langInterval != null) {
            clearInterval(langInterval);
            langInterval = null;
          }
          var regScreen = Alloy.createController("Login").getView();
          regScreen.open();
          Alloy.Globals.drawer.close();
          Alloy.Globals.currentWindow = null;
          Ti.App.Properties.setString("hotel_id", "");
          Ti.App.Properties.setString("visitor_code", "");
          Ti.App.Properties.setString("locale", "en");
          Ti.App.Properties.setString("room_number", "");
          Ti.API.info('-------------');


        } else {
          Ti.API.info('The cancel button was clicked');
        }
      });
      dialog.show();
    }
  }


  if (true) {
    $.topview.width = Alloy.Globals.homedrawerWidth + 30;
  }




  function openFun(e) {
    $.containerVW.animate({
      opacity: 1,
      duration: 500 });


    if (!Ti.App.Properties.getString("isHelpScreenOpen")) {
      setTimeout(function (e) {
        Alloy.createController("HelpScreen").getView().open();
      }, 1000);
    }
  }


  Alloy.Globals.updatedata = function (res) {
    if (res.image != "") {
      $.imge1.image = res.image;
      $.imge.image = res.image;
    } else {
      $.imge.image = '/images/user_img.png';
    }
    if (res.UserRole == "Supervisor") {

      $.nameLbl.text = res.first_name_en;

      var text = Alloy.Globals.langConvert("home_header") + ",\n" + res.first_name_en;


    } else {
      Ti.API.info('in client lang is ' + lang);

      Ti.API.info('name changed ');
      $.nameLbl.text = res.contact_person_en.capitalize();
      var text = Alloy.Globals.langConvert("home_header") + ",\n" + res.contact_person_en.capitalize();

    }
  };


  Alloy.Globals.updatedataAr = function (res) {
    if (res.image != "") {
      $.imge1.image = res.image;
      $.imge.image = res.image;
    } else {
      $.imge1.image = '/images/user_img.png';
    }
    if (res.UserRole == "Supervisor") {
      $.nameLbl1.text = res.first_name_ar;

      var text = Alloy.Globals.langConvert("home_header") + ",\n" + res.first_name_ar;


    } else {
      Ti.API.info('in client lang is ' + lang);
      Ti.API.info('name changed 45346');
      $.nameLbl1.text = res.contact_person_ar;
      var text = Alloy.Globals.langConvert("home_header") + ",\n" + res.contact_person_ar;

    }
  };

  var logoutInterval = null;
  var langInterval = null;
  logoutInterval = setInterval(function () {
    logoutService();
  }, 10000);

  langInterval = setInterval(function () {
    langService();
  }, 10000);

  Ti.App.addEventListener('pause', function (e) {

    Ti.API.info("pause......");
    if (logoutInterval) {
      clearInterval(logoutInterval);
      logoutInterval = null;
    }
    if (langInterval) {
      clearInterval(langInterval);
      langInterval = null;
    }
  });

  Ti.App.addEventListener('resumed', function (e) {

    if (logoutInterval != null) {
      clearInterval(logoutInterval);
      logoutInterval = null;
    }
    if (langInterval != null) {
      clearInterval(langInterval);
      langInterval = null;
    }

    Ti.API.info("Resume......");
    if (logoutInterval == null) {
      logoutInterval = setInterval(function () {
        logoutService();
      }, 10000);
    }
    if (langInterval == null) {
      langInterval = setInterval(function () {
        langService();
      }, 10000);
    }
  });

  function logoutService() {

    if (Ti.Network.online) {
      Communicator.get("http://myhotelsapp.com/api/api.php?action=GetUserLoginStatus&" + "&visitor_code=" + Ti.App.Properties.getString("visitor_code") + "&hotel_id=" + Ti.App.Properties.getString("hotel_id"), logoutCallback);

    }
  }





  function logoutCallback(e) {

    if (e.success) {
      try {

        var response = JSON.parse(e.response);

        if (response != null) {

          if (response.login_status == '0') {

            if (logoutInterval != null) {
              clearInterval(logoutInterval);
              logoutInterval = null;
            }
            if (langInterval != null) {
              clearInterval(langInterval);
              langInterval = null;
            }

            var regScreen = Alloy.createController("Login").getView();
            regScreen.open();
            Alloy.Globals.drawer.close();
            Alloy.Globals.currentWindow = null;
            Ti.App.Properties.setString("hotel_id", "");
            Ti.App.Properties.setString("visitor_code", "");
            Ti.App.Properties.setString("locale", "en");
            Ti.App.Properties.setString("room_number", "");
          }
        } else {

        }
      } catch (e) {
        Ti.API.info('Error social Login List :: ' + e.message);
      }
    } else {


    }
  }

  function langService() {

    if (Ti.Network.online) {
      Communicator.get("http://myhotelsapp.com/api/api.php?action=GetUserCurrentLanguage&" + "&room_number=" + Ti.App.Properties.getString("room_number") + "&hotel_id=" + Ti.App.Properties.getString("hotel_id"), langCallback);

    }
  }





  function langCallback(e) {

    if (e.success) {
      try {

        var response = JSON.parse(e.response);

        if (response != null) {

          if (response.success == '1') {

            if (Titanium.App.Properties.getString('locale')) {
              var chklang = Titanium.App.Properties.getString('locale');
              if (chklang.toUpperCase() != response.language) {
                Titanium.App.Properties.setString('locale', response.language.toLowerCase());
                lang = Titanium.App.Properties.getString('locale');
                changelang();
              }
            }
          }
        } else {

        }
      } catch (e) {
        Ti.API.info('Error social Login List :: ' + e.message);
      }
    } else {


    }
  }




  function changelang() {

    if (lang == "ar") {
      sample_data = [{
        title: Alloy.Globals.langConvert("hotel_activity"),
        image: '/images/image_2.jpg',
        name: "ha" },
      {
        title: Alloy.Globals.langConvert("food_menu"),
        image: '/images/image_1.jpg',
        name: "fm" },
      {
        title: Alloy.Globals.langConvert("about_us"),
        image: '/images/image_4.jpg',
        name: "au" },
      {
        title: Alloy.Globals.langConvert("touristic_places"),
        image: '/images/image_3.jpg',
        name: "tp" },
      {
        title: "",
        image: '',
        name: "white" },
      {
        title: Alloy.Globals.langConvert("write_to_us"),
        image: '/images/image_5.jpg',
        name: "wu" }];

      renderHomeGrid(sample_data);

      $.homeWin.title = Alloy.Globals.langConvert("home");

      $.welcomeLbl1.text = Alloy.Globals.langConvert("welcome") + " " + Ti.App.Properties.getString("room_number");
      $.homeRowLbl1.text = Alloy.Globals.langConvert("home");
      $.foodMenuLbl1.text = Alloy.Globals.langConvert("hotel_activity");
      $.hotelActivityLbl1.text = Alloy.Globals.langConvert("hotel_activity");
      $.foodMenuLbl1.text = Alloy.Globals.langConvert("food_menu");
      $.aboutUsLbl1.text = Alloy.Globals.langConvert("about_us");
      $.touristicPlaceLbl1.text = Alloy.Globals.langConvert("touristic_places");
      $.rateUsLbl1.text = Alloy.Globals.langConvert("write_to_us");
      $.logoutLbl1.text = Alloy.Globals.langConvert("logout");
      $.homeWin.leftNavButton = notificationBtn;
      $.homeWin.rightNavButton = toggleBtn;

      if (Alloy.Globals.drawer.isAnyViewOpen()) {
        Alloy.Globals.drawer.closeOpenView();
      }
      Alloy.Globals.drawer.rightWindow = Alloy.Globals.homeObj.rightWindow;
      Alloy.Globals.drawer.leftWindow = null;
      Alloy.Globals.loadingLbl.text = Alloy.Globals.langConvert("loading");
      Alloy.Globals.goToHome(Alloy.Globals.currentWindow);
    } else {
      Alloy.Globals.loadingLbl.text = Alloy.Globals.langConvert("loading");
      $.homeRowLbl.text = Alloy.Globals.langConvert("home");
      $.logoutLbl.text = Alloy.Globals.langConvert("logout");
      $.welcomeLbl.text = Alloy.Globals.langConvert("welcome") + " " + Ti.App.Properties.getString("room_number");
      $.foodMenuLbl.text = Alloy.Globals.langConvert("hotel_activity");
      $.hotelActivityLbl.text = Alloy.Globals.langConvert("hotel_activity");
      $.foodMenuLbl.text = Alloy.Globals.langConvert("food_menu");
      $.aboutUsLbl.text = Alloy.Globals.langConvert("about_us");
      $.touristicPlaceLbl.text = Alloy.Globals.langConvert("touristic_places");
      $.rateUsLbl.text = Alloy.Globals.langConvert("write_to_us");

      sample_data = [{
        title: Alloy.Globals.langConvert("food_menu"),
        image: '/images/image_1.jpg',

        name: "fm" },
      {
        title: Alloy.Globals.langConvert("hotel_activity"),
        image: '/images/image_2.jpg',
        name: "ha" },
      {
        title: Alloy.Globals.langConvert("touristic_places"),
        image: '/images/image_3.jpg',
        name: "tp" },
      {
        title: Alloy.Globals.langConvert("about_us"),
        image: '/images/image_4.jpg',
        name: "au" },
      {
        title: Alloy.Globals.langConvert("write_to_us"),
        image: '/images/image_5.jpg',
        name: "wu" }];

      renderHomeGrid(sample_data);
      $.homeWin.leftNavButton = toggleBtn;
      $.homeWin.rightNavButton = notificationBtn;

      $.homeWin.title = Alloy.Globals.langConvert("home");
      Alloy.Globals.drawer.leftWindow = Alloy.Globals.homeObj.leftWindow;
      Alloy.Globals.drawer.rightWindow = null;

      if (Alloy.Globals.drawer.isAnyViewOpen()) {
        Alloy.Globals.drawer.closeOpenView();
      }
      Alloy.Globals.goToHome(Alloy.Globals.currentWindow);
    }
  };





  __defers['$.__views.rightTable!click!leftMenuOptionSelected'] && $.addListener($.__views.rightTable, 'click', leftMenuOptionSelected);__defers['$.__views.rightTable!click!leftMenuOptionSelected'] && $.addListener($.__views.rightTable, 'click', leftMenuOptionSelected);if (true) {
    __defers['$.__views.homeWin!open!openFun'] && $.addListener($.__views.homeWin, 'open', openFun);}




  _.extend($, exports);
}

module.exports = Controller;