var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
  var arg = null;
  if (obj) {
    arg = obj[key] || null;
    delete obj[key];
  }
  return arg;
}

function Controller() {

  require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
  this.__controllerPath = 'HotelActivityCategory';
  this.args = arguments[0] || {};

  if (arguments[0]) {
    var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
    var $model = __processArg(arguments[0], '$model');
    var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
  }
  var $ = this;
  var exports = {};
  var __defers = {};







  $.__views.HotelActivityCategory = Ti.UI.createWindow(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    Alloy.deepExtend(true, o, { backButtonTitle: "", backButtonTitleImage: "none", id: "HotelActivityCategory" });
    return o;
  }());

  $.__views.HotelActivityCategory && $.addTopLevelView($.__views.HotelActivityCategory);
  $.__views.fg = Alloy.createWidget('com.prodz.tiflexigrid', 'widget', { id: "fg", __parentSymbol: $.__views.HotelActivityCategory });
  $.__views.fg.setParent($.__views.HotelActivityCategory);
  exports.destroy = function () {};




  _.extend($, $.__views);



  var args = $.args;
  var tableData = [];

  var lang = Titanium.App.Properties.getString('locale');

  if (true) {

    var btnVW = Titanium.UI.createView({
      width: 40,
      height: 40 });



    var toggleBtn = Titanium.UI.createButton({
      backgroundImage: "none" });

    btnVW.add(toggleBtn);

    Ti.API.info('2222');
    if (lang == "ar") {
      toggleBtn.right = 0;
      toggleBtn.image = "/images/barrow_ar.png";
    } else {
      toggleBtn.left = 0;
      toggleBtn.image = "/images/back.png";
    }

    var notificationBtn = Titanium.UI.createButton({
      backgroundImage: "none",
      image: "/images/notification.png",
      visible: true });



    if (args.length > 0) {
      $.HotelActivityCategory.title = args[0].type;
    } else {
      $.HotelActivityCategory.title = Alloy.Globals.langConvert("hotel_activity");
    }
    if (lang == "ar") {
      $.HotelActivityCategory.leftNavButton = notificationBtn;
      $.HotelActivityCategory.rightNavButton = btnVW;
    } else {
      $.HotelActivityCategory.leftNavButton = btnVW;
      $.HotelActivityCategory.rightNavButton = notificationBtn;
    }
    btnVW.addEventListener('click', function (e) {
      $.HotelActivityCategory.close();
    });
    notificationBtn.addEventListener("click", function (e) {

      var mycart = Alloy.createController("MyCart").getView();
      Alloy.Globals.navWin.openWindow(mycart);
      mycart.oldWin = $.HotelActivityCategory;
      Alloy.Globals.currentWindow = mycart;
    });
  }

  $.fg.init({
    columns: 2,
    space: 0,
    gridBackgroundColor: '#fff',
    itemHeightDelta: 0,
    itemBackgroundColor: '#eee',
    itemBorderColor: 'transparent',
    itemBorderWidth: 0,
    itemBorderRadius: 0 });


  var items = [];
  var menu_data = [];

  function renderHomeGrid(sample_data) {
    items = [];
    for (var x = 0; x < sample_data.length; x++) {
      Ti.API.info('--------');

      var view = Ti.UI.createView({});

      if (lang == "ar") {
        if (x == 4) {
          view.backgroundColor = "white";
        } else {
          var img = Ti.UI.createImageView({
            image: "http://myhotelsapp.com/hotel/uploads/activity/" + sample_data[x].image,
            width: Ti.UI.FILL,
            height: Ti.UI.FILL });

          view.add(img);
          var titleVW = Ti.UI.createView({
            backgroundColor: "#dc0474",
            height: 40 * Alloy.Globals.scaleFactor,
            bottom: 0 });

          view.add(titleVW);
          var title = Ti.UI.createLabel({
            textAlign: "center",
            font: {
              fontSize: 13 * Alloy.Globals.scaleFactor },

            text: sample_data[x].title,
            color: "white" });

          titleVW.add(title);
        }
      } else {
        var img = Ti.UI.createImageView({
          image: "http://myhotelsapp.com/hotel/uploads/activity/" + sample_data[x].image,
          width: Ti.UI.FILL,
          height: Ti.UI.FILL });

        view.add(img);
        var titleVW = Ti.UI.createView({
          backgroundColor: "#dc0474",
          height: 40 * Alloy.Globals.scaleFactor,
          bottom: 0 });

        view.add(titleVW);
        var title = Ti.UI.createLabel({
          textAlign: "center",
          font: {
            fontSize: 13 * Alloy.Globals.scaleFactor },

          text: sample_data[x].title,
          color: "white" });

        titleVW.add(title);
      }


      var values = {
        title: sample_data[x].title };




      items.push({
        view: view,
        data: sample_data[x] });

    };
    $.fg.addGridItems(items);
    $.fg.setOnItemClick(function (e) {
      Ti.API.info('e' + JSON.stringify(e.source.data));

      var mycart = Alloy.createController("HotelActivityCategoryDetail", e.source.data).getView();
      Alloy.Globals.navWin.openWindow(mycart);
      mycart.oldWin = $.HotelActivityCategory;
      Alloy.Globals.currentWindow = mycart;
    });
  }

  renderHomeGrid(args);









  _.extend($, exports);
}

module.exports = Controller;