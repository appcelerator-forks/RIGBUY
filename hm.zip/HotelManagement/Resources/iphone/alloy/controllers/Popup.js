var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
  var arg = null;
  if (obj) {
    arg = obj[key] || null;
    delete obj[key];
  }
  return arg;
}

function Controller() {

  require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
  this.__controllerPath = 'Popup';
  this.args = arguments[0] || {};

  if (arguments[0]) {
    var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
    var $model = __processArg(arguments[0], '$model');
    var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
  }
  var $ = this;
  var exports = {};
  var __defers = {};







  $.__views.popupWin = Ti.UI.createWindow(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    Alloy.deepExtend(true, o, { id: "popupWin", backgroundColor: "transparent", opacity: 0 });
    return o;
  }());

  $.__views.popupWin && $.addTopLevelView($.__views.popupWin);
  openFunc ? $.addListener($.__views.popupWin, 'open', openFunc) : __defers['$.__views.popupWin!open!openFunc'] = true;winClickFunc ? $.addListener($.__views.popupWin, 'click', winClickFunc) : __defers['$.__views.popupWin!click!winClickFunc'] = true;$.__views.outerVW = Ti.UI.createView(
  { id: "outerVW", backgroundColor: "black", opacity: 0.6 });

  $.__views.popupWin.add($.__views.outerVW);
  $.__views.__alloyId27 = Ti.UI.createView(
  { backgroundColor: "white", height: "68%", width: "92%", layout: "vertical", id: "__alloyId27" });

  $.__views.popupWin.add($.__views.__alloyId27);
  $.__views.__alloyId28 = Ti.UI.createView(
  { top: 4, width: "92%", height: Ti.UI.SIZE, id: "__alloyId28" });

  $.__views.__alloyId27.add($.__views.__alloyId28);
  $.__views.foodItemStaticLbl = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { text: 'Food Item', id: "foodItemStaticLbl", color: "black" });
    return o;
  }());

  $.__views.__alloyId28.add($.__views.foodItemStaticLbl);
  $.__views.cancelBtn = Ti.UI.createButton(
  { title: 'Cancel', backgroundColor: "transparent", color: "#dc0474", id: "cancelBtn", backgroundImage: "none" });

  $.__views.__alloyId28.add($.__views.cancelBtn);
  closeWin ? $.addListener($.__views.cancelBtn, 'click', closeWin) : __defers['$.__views.cancelBtn!click!closeWin'] = true;$.__views.foodImg = Ti.UI.createImageView(
  { id: "foodImg", top: 10, height: "38%", width: "92%" });

  $.__views.__alloyId27.add($.__views.foodImg);
  $.__views.titleLbl = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { text: 'Testing', id: "titleLbl", textAlign: "center", top: 10, width: "92%", ellipsize: Titanium.UI.TEXT_ELLIPSIZE_TRUNCATE_END, height: "5%", color: "#7e7d85" });
    return o;
  }());

  $.__views.__alloyId27.add($.__views.titleLbl);
  $.__views.descLbl = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { text: 'Testing', id: "descLbl", verticalAlign: Titanium.UI.TEXT_VERTICAL_ALIGNMENT_TOP, textAlign: "justify", top: 10, width: "92%", ellipsize: Titanium.UI.TEXT_ELLIPSIZE_TRUNCATE_END, height: "22%", color: "#7e7d85" });
    return o;
  }());

  $.__views.__alloyId27.add($.__views.descLbl);
  $.__views.priceLbl = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { text: '$. 200', id: "priceLbl", textAlign: "center", top: 2, width: "92%", ellipsize: Titanium.UI.TEXT_ELLIPSIZE_TRUNCATE_END, height: "4%", color: "#7e7d85" });
    return o;
  }());

  $.__views.__alloyId27.add($.__views.priceLbl);
  $.__views.orderVW = Ti.UI.createView(
  { top: 10, id: "orderVW", width: "92%", height: "10%" });

  $.__views.__alloyId27.add($.__views.orderVW);
  $.__views.__alloyId29 = Ti.UI.createView(
  { width: "100%", height: Ti.UI.FILL, id: "__alloyId29" });

  $.__views.orderVW.add($.__views.__alloyId29);
  $.__views.leftVW = Ti.UI.createView(
  { id: "leftVW", visible: false, layout: "horizontal", width: Ti.UI.SIZE });

  $.__views.__alloyId29.add($.__views.leftVW);
  $.__views.minusBtn = Ti.UI.createButton(
  { id: "minusBtn", width: 40, backgroundColor: "black", height: Ti.UI.FILL, title: "-", color: "white" });

  $.__views.leftVW.add($.__views.minusBtn);
  minusFunc ? $.addListener($.__views.minusBtn, 'click', minusFunc) : __defers['$.__views.minusBtn!click!minusFunc'] = true;$.__views.qtyLbl = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { text: '1', id: "qtyLbl", width: 50, textAlign: "center", height: "100%", ellipsize: Titanium.UI.TEXT_ELLIPSIZE_TRUNCATE_END, backgroundColor: "#bfbbba", color: "#000" });
    return o;
  }());

  $.__views.leftVW.add($.__views.qtyLbl);
  $.__views.plusBtn = Ti.UI.createButton(
  { id: "plusBtn", width: 40, backgroundColor: "black", height: Ti.UI.FILL, title: "+", color: "white" });

  $.__views.leftVW.add($.__views.plusBtn);
  plusFunc ? $.addListener($.__views.plusBtn, 'click', plusFunc) : __defers['$.__views.plusBtn!click!plusFunc'] = true;$.__views.bookBtn = Ti.UI.createButton(
  { title: 'BOOK ORDER', id: "bookBtn", width: "40%", backgroundColor: "#3ec73d", height: Ti.UI.FILL, color: "white", right: 0 });

  $.__views.__alloyId29.add($.__views.bookBtn);
  bookOrderFunc ? $.addListener($.__views.bookBtn, 'click', bookOrderFunc) : __defers['$.__views.bookBtn!click!bookOrderFunc'] = true;$.__views.goToCartBtn = Ti.UI.createButton(
  { title: 'GO TO CART', id: "goToCartBtn", visible: false, height: Ti.UI.FILL, width: "100%", backgroundColor: "#3ec73d", color: "white", right: 0 });

  $.__views.orderVW.add($.__views.goToCartBtn);
  goToCart ? $.addListener($.__views.goToCartBtn, 'click', goToCart) : __defers['$.__views.goToCartBtn!click!goToCart'] = true;exports.destroy = function () {};




  _.extend($, $.__views);



  var args = $.args;

  var lang = Titanium.App.Properties.getString('locale');


  var Communicator = Alloy.Globals.Communicator;
  var DOMAIN_URL = Alloy.Globals.Constants.DOMAIN_URL;

  Ti.API.info('ARGS : ' + JSON.stringify(args));
  $.titleLbl.text = args.data.title;
  $.foodImg.image = "http://myhotelsapp.com/hotel/uploads/food/" + args.data.image;
  $.descLbl.text = args.data.desc;
  $.priceLbl.text = "$. " + args.data.price;
  $.cancelBtn.height = 26 * Alloy.Globals.scaleFactor;

  $.foodItemStaticLbl.font = {
    fontSize: 13 * Alloy.Globals.scaleFactor };


  var finalPrice = parseInt(args.data.price);
  var price = args.data.price;

  $.foodItemStaticLbl.text = Alloy.Globals.langConvert("foodItem");
  $.cancelBtn.title = Alloy.Globals.langConvert("cancel");
  if (lang == "ar") {
    $.leftVW.right = 0;
    $.bookBtn.left = 0;
    $.foodItemStaticLbl.textAlign = "right";
    $.foodItemStaticLbl.right = 0;
    $.cancelBtn.left = 0;
  } else {
    $.leftVW.left = 0;
    $.bookBtn.right = 0;
    $.foodItemStaticLbl.textAlign = "left";
    $.foodItemStaticLbl.left = 0;
    $.cancelBtn.right = 0;
  }
  $.foodItemStaticLbl.font = {
    fontSize: 16 * Alloy.Globals.scaleFactor };

  $.titleLbl.font = {
    fontSize: 16 * Alloy.Globals.scaleFactor };

  $.descLbl.font = {
    fontSize: 13 * Alloy.Globals.scaleFactor };

  $.priceLbl.font = {
    fontSize: 14 * Alloy.Globals.scaleFactor };

  $.minusBtn.width = 40 * Alloy.Globals.scaleFactor;
  $.plusBtn.width = 40 * Alloy.Globals.scaleFactor;
  function openFunc(e) {
    $.popupWin.animate({
      duration: 500,
      opacity: 1 });

  }

  function closeWin() {
    $.popupWin.animate({
      duration: 500,
      opacity: 0 });

    setTimeout(function (e) {
      $.popupWin.close();
    }, 500);
  }
  function winClickFunc(e) {
    if (e.source.id == "outerVW") {
      $.popupWin.animate({
        duration: 500,
        opacity: 0 });

      setTimeout(function (e) {
        $.popupWin.close();
      }, 500);
    }
  }

  try {

    Ti.API.info('Alloy.Globals.myCartArray ' + JSON.stringify(Alloy.Globals.myCartArray));
    Ti.API.info('args.food_id ' + args.data.food_id);
    if (Alloy.Globals.myCartArray.length > 0) {
      for (var i = 0; i < Alloy.Globals.myCartArray.length; i++) {
        if (Alloy.Globals.myCartArray[i].food_id == args.data.food_id) {
          Ti.API.info('1');
          $.leftVW.visible = false;
          $.goToCartBtn.visible = true;
          break;
        } else {
          Ti.API.info('2');
          $.leftVW.visible = true;
          $.goToCartBtn.visible = false;
        }
      };
    } else {
      Ti.API.info('3');
      $.leftVW.visible = true;
      $.goToCartBtn.visible = false;
    }
  } catch (e) {
    Ti.API.info('Calcultaion : ' + e.message);
  }

  function minusFunc(e) {
    if ($.qtyLbl.text > 1) {
      $.qtyLbl.text = parseInt($.qtyLbl.text) - 1;
      $.priceLbl.text = "$. " + parseInt(price) * parseInt($.qtyLbl.text);
      Ti.API.info("MINUS __ " + $.qtyLbl.text);
      finalPrice = parseInt(price) * parseInt($.qtyLbl.text);
    }
  }

  function plusFunc(e) {
    $.qtyLbl.text = parseInt($.qtyLbl.text) + 1;
    $.priceLbl.text = "$. " + parseInt(price) * parseInt($.qtyLbl.text);
    Ti.API.info("PLUS __ " + $.qtyLbl.text);
    finalPrice = parseInt(price) * parseInt($.qtyLbl.text);
  }

  function goToCart(e) {
    $.popupWin.animate({
      duration: 500,
      opacity: 0 });

    setTimeout(function (e) {
      $.popupWin.close();
    }, 500);
    var mycart = Alloy.createController("MyCart").getView();
    Alloy.Globals.navWin.openWindow(mycart);
    mycart.oldWin = args.winObj;
    Alloy.Globals.currentWindow = mycart;
  }

  function bookOrderFunc(e) {
    Ti.API.info('Price :' + finalPrice);
    Ti.API.info('qty :' + $.qtyLbl.text);
    Ti.API.info('food_id :' + args.data.food_id);
    bookOrderedService(args.data.food_id, $.qtyLbl.text, finalPrice);
  }

  function bookOrderedService(food_id, qty, price) {
    var params = "language=" + Ti.App.Properties.getString("locale") + "&hotel_id=" + Ti.App.Properties.getString("hotel_id") + "&food_id=" + food_id + "&visitor_code=" + Ti.App.Properties.getString("visitor_code") + "&qty=" + qty + "&price=" + price;
    Ti.API.info('PARAMS  ' + params);
    if (Ti.Network.online) {
      Alloy.Globals.LoadingScreen.open();
      Communicator.get("http://myhotelsapp.com/api/api.php?action=VisitorOrder&" + params, bookOrderedServiceCallback);
      Ti.API.info('URL : ' + "http://myhotelsapp.com/api/api.php?action=VisitorOrder&" + params);
    } else {
      Alloy.Globals.Alert(Alloy.Globals.langConvert("internat_connection_message"));
    }
  }





  function bookOrderedServiceCallback(e) {
    Ti.API.info("bookOrderedServiceCallback Callback response : " + JSON.stringify(e));
    if (e.success) {
      try {

        var response = JSON.parse(e.response);

        if (response != null) {
          Ti.API.info('response.action_success = ' + JSON.stringify(response));
          if (response.success == '1') {
            $.popupWin.animate({
              duration: 500,
              opacity: 0 });

            setTimeout(function (e) {
              $.popupWin.close();
            }, 300);
            var mycart = Alloy.createController("MyCart").getView();
            Alloy.Globals.navWin.openWindow(mycart);
            mycart.oldWin = args.winObj;
            Alloy.Globals.currentWindow = mycart;
          } else {
            Alloy.Globals.Alert(response.msg);
          }
        } else {
          Alloy.Globals.Alert(Alloy.Globals.Constants.MSG_NO_DATA);
        }
      } catch (e) {
        Ti.API.info('Error social Login List :: ' + e.message);
      }
    } else {
      Alloy.Globals.Alert(Alloy.Globals.langConvert("network_validation"));
    }

    Alloy.Globals.LoadingScreen.close();
  }





  __defers['$.__views.popupWin!open!openFunc'] && $.addListener($.__views.popupWin, 'open', openFunc);__defers['$.__views.popupWin!click!winClickFunc'] && $.addListener($.__views.popupWin, 'click', winClickFunc);__defers['$.__views.cancelBtn!click!closeWin'] && $.addListener($.__views.cancelBtn, 'click', closeWin);__defers['$.__views.minusBtn!click!minusFunc'] && $.addListener($.__views.minusBtn, 'click', minusFunc);__defers['$.__views.plusBtn!click!plusFunc'] && $.addListener($.__views.plusBtn, 'click', plusFunc);__defers['$.__views.bookBtn!click!bookOrderFunc'] && $.addListener($.__views.bookBtn, 'click', bookOrderFunc);__defers['$.__views.goToCartBtn!click!goToCart'] && $.addListener($.__views.goToCartBtn, 'click', goToCart);



  _.extend($, exports);
}

module.exports = Controller;