var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
  var arg = null;
  if (obj) {
    arg = obj[key] || null;
    delete obj[key];
  }
  return arg;
}

function Controller() {

  require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
  this.__controllerPath = 'RateUs';
  this.args = arguments[0] || {};

  if (arguments[0]) {
    var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
    var $model = __processArg(arguments[0], '$model');
    var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
  }
  var $ = this;
  var exports = {};
  var __defers = {};







  $.__views.RateUs = Ti.UI.createWindow(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 16, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { backgroundColor: "#ffffff", titleAttributes: { color: "#ffffff", font: { fontSize: 18, fontFamily: "Roboto-Regular" } }, navTintColor: "#dc0474", barColor: "#dc0474", translucent: false, statusBarStyle: Ti.UI.iOS.StatusBar.LIGHT_CONTENT });
    Alloy.deepExtend(true, o, { backButtonTitle: "", backButtonTitleImage: "none", backgroundColor: "black", name: "RateUs", id: "RateUs" });
    return o;
  }());

  $.__views.RateUs && $.addTopLevelView($.__views.RateUs);
  openFunc ? $.addListener($.__views.RateUs, 'open', openFunc) : __defers['$.__views.RateUs!open!openFunc'] = true;$.__views.AboutUsLbl = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { id: "AboutUsLbl", top: "6%", color: "white" });
    return o;
  }());

  $.__views.RateUs.add($.__views.AboutUsLbl);
  $.__views.__alloyId30 = Ti.UI.createScrollView(
  { top: "16%", bottom: 0, id: "__alloyId30" });

  $.__views.RateUs.add($.__views.__alloyId30);
  $.__views.webview = Ti.UI.createLabel(
  function () {
    var o = {};
    if (Alloy.isHandheld) Alloy.deepExtend(true, o, { font: { fontSize: 16, fontFamily: "Roboto-Regular" } });
    if (Alloy.Globals.iPhoneTallSixPlus) Alloy.deepExtend(true, o, { font: { fontSize: 18, fontFamily: "Roboto-Regular" } });
    Alloy.deepExtend(true, o, { id: "webview", color: "white", top: 0, left: "3%", right: "3%", textAlign: "justify", height: Ti.UI.SIZE });
    return o;
  }());

  $.__views.__alloyId30.add($.__views.webview);
  exports.destroy = function () {};




  _.extend($, $.__views);



  var args = $.args;

  var lang = Titanium.App.Properties.getString('locale');


  var Communicator = Alloy.Globals.Communicator;
  var DOMAIN_URL = Alloy.Globals.Constants.DOMAIN_URL;

  $.AboutUsLbl.font = {
    fontSize: 24 * Alloy.Globals.scaleFactor };

  $.webview.font = {
    fontSize: 14 * Alloy.Globals.scaleFactor };



  if (true) {

    var btnVW = Titanium.UI.createView({
      width: 40,
      height: 40 });



    var toggleBtn = Titanium.UI.createButton({
      backgroundImage: "none" });

    btnVW.add(toggleBtn);
    if (args == "menu") {

      Ti.API.info('111111111');
      toggleBtn.image = "/images/menu.png";
      if (lang == "ar") {
        toggleBtn.right = 0;
      } else {
        toggleBtn.left = 0;
      }
    } else {

      Ti.API.info('2222');
      if (lang == "ar") {
        toggleBtn.right = 0;
        toggleBtn.image = "/images/barrow_ar.png";
      } else {
        toggleBtn.left = 0;
        toggleBtn.image = "/images/back.png";
      }
    }

    var notificationBtn = Titanium.UI.createButton({
      backgroundImage: "none",
      image: "/images/notification.png",
      visible: true });


    $.RateUs.title = Alloy.Globals.langConvert("write_to_us");
    $.AboutUsLbl.text = Alloy.Globals.langConvert("write_to_us");
    if (lang == "ar") {
      $.RateUs.leftNavButton = notificationBtn;
      $.RateUs.rightNavButton = btnVW;
    } else {
      $.RateUs.leftNavButton = btnVW;
      $.RateUs.rightNavButton = notificationBtn;
    }

    btnVW.addEventListener('click', toggleLeftView);

    notificationBtn.addEventListener("click", function (e) {

      var mycart = Alloy.createController("MyCart").getView();
      Alloy.Globals.navWin.openWindow(mycart);
      mycart.oldWin = $.RateUs;
      Alloy.Globals.currentWindow = mycart;
    });
  }




  function toggleLeftView() {
    if (args == "menu") {

      if (lang == "ar") {
        Ti.API.info("langtoggle1 " + lang);
        Alloy.Globals.openRight();
      } else {
        Ti.API.info("langtoggle2 " + lang);
        Alloy.Globals.openLeft();
      }
    } else {
      $.RateUs.close();
    }
  }

  function openFunc(e) {
    aboutUsService();
  }

  function aboutUsService() {

    if (Ti.Network.online) {
      Alloy.Globals.LoadingScreen.open();
      Communicator.get("http://myhotelsapp.com/api/api.php?action=WriteToUs&" + "language=" + Ti.App.Properties.getString("locale") + "&hotel_id=" + Ti.App.Properties.getString("hotel_id"), aboutUsServiceCallback);
      Ti.API.info('URL : ' + "http://myhotelsapp.com/api/api.php?action=WriteToUs&" + "language=" + Ti.App.Properties.getString("locale") + "&hotel_id=" + Ti.App.Properties.getString("hotel_id"));
    } else {
      Alloy.Globals.Alert(Alloy.Globals.langConvert("internat_connection_message"));
    }
  }





  function aboutUsServiceCallback(e) {
    Ti.API.info("aboutUsServiceCallback Callback response : " + JSON.stringify(e));
    if (e.success) {


      var response = JSON.parse(e.response);

      if (response != null) {
        Ti.API.info('response.action_success = ' + JSON.stringify(response));
        if (response.success == '1') {

          var html2as = require('nl.fokkezb.html2as');

          html2as(response.content, function (err, as) {

            if (err) {
              console.error(err);
            } else {

              $.webview.attributedString = as;
            }
          });
        } else {
          Alloy.Globals.Alert(response.msg);
        }
      } else {
        Alloy.Globals.Alert(Alloy.Globals.Constants.MSG_NO_DATA);
      }




    } else {
      Alloy.Globals.Alert(Alloy.Globals.langConvert("network_validation"));
    }

    Alloy.Globals.LoadingScreen.close();
  }





  __defers['$.__views.RateUs!open!openFunc'] && $.addListener($.__views.RateUs, 'open', openFunc);



  _.extend($, exports);
}

module.exports = Controller;