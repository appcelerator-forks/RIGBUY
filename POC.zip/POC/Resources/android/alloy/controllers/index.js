var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
  var arg = null;
  if (obj) {
    arg = obj[key] || null;
    delete obj[key];
  }
  return arg;
}

function Controller() {

  require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
  this.__controllerPath = 'index';
  this.args = arguments[0] || {};

  if (arguments[0]) {
    var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
    var $model = __processArg(arguments[0], '$model');
    var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
  }
  var $ = this;
  var exports = {};
  var __defers = {};







  $.__views.index = Ti.UI.createWindow(
  { backgroundColor: "#1c141b", theme: "Theme.Titanium", modal: true, id: "index" });

  $.__views.index && $.addTopLevelView($.__views.index);
  openFunc ? $.addListener($.__views.index, 'open', openFunc) : __defers['$.__views.index!open!openFunc'] = true;backfunc ? $.addListener($.__views.index, 'android:back', backfunc) : __defers['$.__views.index!android:back!backfunc'] = true;$.__views.webView = Ti.UI.createWebView(
  { top: 0, id: "webView", cacheMode: Ti.UI.Android.WEBVIEW_LOAD_CACHE_ELSE_NETWORK, borderRadius: 1, enableZoomControls: false, url: "http://day2daymart.com", height: "100%", width: "100%" });

  $.__views.index.add($.__views.webView);
  tourchStartFunc ? $.addListener($.__views.webView, 'touchstart', tourchStartFunc) : __defers['$.__views.webView!touchstart!tourchStartFunc'] = true;errorFunc ? $.addListener($.__views.webView, 'error', errorFunc) : __defers['$.__views.webView!error!errorFunc'] = true;beforeLoadFunc ? $.addListener($.__views.webView, 'beforeload', beforeLoadFunc) : __defers['$.__views.webView!beforeload!beforeLoadFunc'] = true;loadCompeleteFunc ? $.addListener($.__views.webView, 'load', loadCompeleteFunc) : __defers['$.__views.webView!load!loadCompeleteFunc'] = true;exports.destroy = function () {};




  _.extend($, $.__views);


  var url = "httpls://day2daymart.com";
  function loadCompeleteFunc(e) {
    Ti.API.info('1' + JSON.stringify(e));
    url = e.source.url;
    Alloy.Globals.LoadingScreen.close();
  }

  function beforeLoadFunc(e) {
    Ti.API.info('1' + e.source.url);
  }

  $.index.open();
  function errorFunc(e) {
    Ti.API.info('*****Error*****');
    Alloy.Globals.LoadingScreen.close();
  }

  var win = null;
  var isOffline = false;
  function openFunc(e) {
    if (Ti.Network.online) {
      Alloy.Globals.LoadingScreen.open();
    } else {
      offlineWindow();
    }
  }
  function tourchStartFunc(e) {
    if (Ti.Network.online) {} else {
      $.webView.stopLoading();
      offlineWindow();
    }
  }
  function backfunc(e) {
    $.webView.goBack();
  }
  function offlineWindow() {
    win = Ti.UI.createWindow({
      theme: "Theme.Titanium",
      backgroundColor: "white",
      layout: "vertical" });

    var lbl = Ti.UI.createLabel({
      text: "Network seems to be offline, Please check your internet and try again",
      color: "black",
      top: "40%",
      textAlign: "center",
      width: "96%",
      font: {
        fontSize: 20 } });


    win.add(lbl);
    var btn = Ti.UI.createButton({
      title: "Refresh",
      color: "white",
      top: 15,
      backgroundColor: "black",
      width: 100 });

    win.add(btn);
    btn.addEventListener("click", function (e) {
      if (Ti.Network.online) {

        win.close();
        win = null;
        Alloy.Globals.LoadingScreen.open();
        $.webView.setUrl(url);
      }
    });
    win.open();
    isOffline = true;
  };
  Ti.Network.addEventListener('change', function (e) {
    Ti.API.info("JSON : " + JSON.stringify(e));
    if (e.source.online) {
      if (isOffline) {
        if (win) {
          win.close();
          Alloy.Globals.LoadingScreen.open();
          $.webView.setUrl(url);
          isOffline = false;
        }
      }
    } else {
      if (win) {
        return;
      }
      isOffline = true;
      if (Alloy.Globals.LoadingScreen) {
        Alloy.Globals.LoadingScreen.close();
      }
      offlineWindow();
    }
  });





  __defers['$.__views.index!open!openFunc'] && $.addListener($.__views.index, 'open', openFunc);__defers['$.__views.index!android:back!backfunc'] && $.addListener($.__views.index, 'android:back', backfunc);__defers['$.__views.webView!touchstart!tourchStartFunc'] && $.addListener($.__views.webView, 'touchstart', tourchStartFunc);__defers['$.__views.webView!error!errorFunc'] && $.addListener($.__views.webView, 'error', errorFunc);__defers['$.__views.webView!beforeload!beforeLoadFunc'] && $.addListener($.__views.webView, 'beforeload', beforeLoadFunc);__defers['$.__views.webView!load!loadCompeleteFunc'] && $.addListener($.__views.webView, 'load', loadCompeleteFunc);



  _.extend($, exports);
}

module.exports = Controller;