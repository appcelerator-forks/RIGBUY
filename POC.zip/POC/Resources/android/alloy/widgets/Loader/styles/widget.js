module.exports = [{ "isId": true, "priority": 100000.0002, "key": "ActivityView", "style": { backgroundColor: "black", opacity: 0.8, width: 120, height: 120, borderRadius: 10 } }, { "isId": true, "priority": 100000.0004, "key": "activityIndicatorAnd", "style": { message: "Please wait...", location: Ti.UI.Android.PROGRESS_INDICATOR_DIALOG, cancelable: false } }, { "isId": true, "priority": 100000.0005, "key": "loadingLabel", "style": { text: "Please wait...", color: "white", bottom: 12, font: { fontSize: 17, fontWeight: "bold" } } }];function WPATH(s) {
	var index = s.lastIndexOf('/');
	var path = index === -1 ? 'Loader/' + s : s.substring(0, index) + '/Loader/' + s.substring(index + 1);

	return path.indexOf('/') !== 0 ? '/' + path : path;
}