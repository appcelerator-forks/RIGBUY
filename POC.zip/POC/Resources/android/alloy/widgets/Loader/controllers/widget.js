var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;


function WPATH(s) {
	var index = s.lastIndexOf('/');
	var path = index === -1 ?
	'Loader/' + s :
	s.substring(0, index) + '/Loader/' + s.substring(index + 1);

	return path.indexOf('/') !== 0 ? '/' + path : path;
}

function __processArg(obj, key) {
	var arg = null;
	if (obj) {
		arg = obj[key] || null;
		delete obj[key];
	}
	return arg;
}

function Controller() {
	var Widget = new (require('/alloy/widget'))('Loader');this.__widgetId = 'Loader';
	require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
	this.__controllerPath = 'widget';
	this.args = arguments[0] || {};

	if (arguments[0]) {
		var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
		var $model = __processArg(arguments[0], '$model');
		var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
	}
	var $ = this;
	var exports = {};
	var __defers = {};







	if (true) {
		$.__views.activityIndicatorAnd = Ti.UI.Android.createProgressIndicator(
		{ message: "Please wait...", location: Ti.UI.Android.PROGRESS_INDICATOR_DIALOG, cancelable: false, id: "activityIndicatorAnd" });

		$.__views.activityIndicatorAnd && $.addTopLevelView($.__views.activityIndicatorAnd);
	}
	exports.destroy = function () {};




	_.extend($, $.__views);



	if (false) {
		$.activityIndicator.show();
	}

	exports.open = function () {

		$.activityIndicatorAnd.show();
	};

	exports.close = function () {

		$.activityIndicatorAnd.hide();
	};









	_.extend($, exports);
}

module.exports = Controller;