var url = "httpls://day2daymart.com";
function loadCompeleteFunc(e) {
	Ti.API.info('1' + JSON.stringify(e));
	url = e.source.url;
	Alloy.Globals.LoadingScreen.close();
}

function beforeLoadFunc(e) {
	Ti.API.info('1' + e.source.url);

}

$.index.open();
function errorFunc(e) {
	Ti.API.info('*****Error*****');
	Alloy.Globals.LoadingScreen.close();
}

var win = null;
var isOffline = false;
function openFunc(e) {
	if (Ti.Network.online) {
		Alloy.Globals.LoadingScreen.open();
	} else {
		offlineWindow();
	}

}
function tourchStartFunc(e) {
	if (Ti.Network.online) {
		
	} else {
		$.webView.stopLoading();
		offlineWindow();
	}

}
function backfunc(e) {
	$.webView.goBack();
}
function offlineWindow(){
	win = Ti.UI.createWindow({
			theme : "Theme.Titanium",
			backgroundColor : "white",
			layout : "vertical"
		});
		var lbl = Ti.UI.createLabel({
			text : "Network seems to be offline, Please check your internet and try again",
			color : "black",
			top : "40%",
			textAlign:"center",
			width:"96%",
			font : {
				fontSize : 20
			}
		});
		win.add(lbl);
		var btn = Ti.UI.createButton({
			title : "Refresh",
			color : "white",
			top : 15,
			backgroundColor : "black",
			width : 100
		});
		win.add(btn);
		btn.addEventListener("click", function(e) {
			if (Ti.Network.online) {

				win.close();
				win = null;
				Alloy.Globals.LoadingScreen.open();
				$.webView.setUrl(url);
			}
		});
		win.open();
		isOffline = true;
};
Ti.Network.addEventListener('change', function(e) {
	Ti.API.info("JSON : " + JSON.stringify(e));
	if (e.source.online) {
		if (isOffline) {
			if (win) {
				win.close();
				Alloy.Globals.LoadingScreen.open();
				$.webView.setUrl(url);
				isOffline=false;
			}
		}
	} else {
		if (win) {
			return;
		}
		isOffline = true;
		if (Alloy.Globals.LoadingScreen) {
			Alloy.Globals.LoadingScreen.close();
		}
		 offlineWindow();
	}
});

